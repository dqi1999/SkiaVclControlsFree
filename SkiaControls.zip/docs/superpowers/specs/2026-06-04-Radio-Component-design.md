# Radio 组件设计文档

## 概述

基于 Material-UI v4 的 Radio Buttons 设计，创建 TDSkRadio 和 TDSkRadioGroup 组件，提供完整的单选按钮功能。

## 设计目标

1. 符合 MUI Radio Buttons 设计规范
2. 支持完整的视觉样式（颜色方案、标签放置、禁用/错误状态）
3. 支持完整的交互行为（点击、键盘、焦点、悬停）
4. 支持垂直和水平布局
5. 与现有组件风格一致

## 组件设计

### TDSkRadio 组件

**继承：** TDSCustomSkControl

**核心属性：**
- `Checked: Boolean` - 选中状态
- `Caption: string` - 标签文本
- `LabelPlacement: TDSkRadioLabelPlacement` - 标签放置（上、下、左、右）
- `ColorScheme: TDSkMUIColorScheme` - MUI 颜色方案
- `RadioSize: Single` - 单选按钮大小
- `Font: TFont` - 标签字体
- `Enabled: Boolean` - 启用状态（继承）
- `Error: Boolean` - 错误状态

**视觉设计：**
- 未选中：空心圆圈（边框颜色）
- 选中：实心小圆 + 外圈（颜色方案颜色）
- 禁用：灰色圆圈
- 错误：红色圆圈
- 悬停：涟漪效果
- 焦点：虚线框

**交互：**
- 点击切换选中状态
- 悬停效果（涟漪）
- 焦点状态（虚线框）
- 键盘导航（空格键选中）

### TDSkRadioGroup 组件

**继承：** TDSCustomSkControl

**核心属性：**
- `Orientation: TDSkRadioGroupOrientation` - 布局方向（垂直/水平）
- `ItemIndex: Integer` - 当前选中项索引
- `Items: TStrings` - 选项文本列表
- `ColorScheme: TDSkMUIColorScheme` - 统一颜色方案
- `LabelPlacement: TDSkRadioLabelPlacement` - 统一标签放置
- `Exclusive: Boolean` - 是否只能选一个（默认 True）

**功能：**
- 自动管理子 Radio 组件的选中状态
- 支持 Exclusive 模式
- 支持 OnItemClick 事件
- 支持 OnChange 事件

**布局：**
- 垂直排列：默认
- 水平排列：通过 Orientation 属性

## 类型定义

在 `SkiaVclControls.Types.pas` 中添加：

```pascal
{ Radio 标签放置 }
TDSkRadioLabelPlacement = (
  rlpTop,     // 标签在上
  rlpBottom,  // 标签在下
  rlpLeft,    // 标签在左
  rlpRight    // 标签在右（默认）
);

{ RadioGroup 布局方向 }
TDSkRadioGroupOrientation = (
  rgoVertical,   // 垂直排列（默认）
  rgoHorizontal  // 水平排列
);
```

## 文件结构

### 新建文件
- `Sources/SkiaVclControls.Radio.pas` - TDSkRadio 组件
- `Sources/SkiaVclControls.RadioGroup.pas` - TDSkRadioGroup 组件
- `Demo/Radio/RadioDemo.dpr` - 演示程序
- `Demo/Radio/RadioMainForm.pas` - 演示窗口
- `Demo/Radio/RadioMainForm.dfm` - 演示窗口布局

### 修改文件
- `Sources/SkiaVclControls.Types.pas` - 添加新枚举类型
- `Sources/SkiaVclControls.Register.pas` - 注册新组件
- `SkiaVclControls.dpk` - 添加新单元

## MUI 颜色方案

使用现有的 TDSkMUIColorScheme 枚举：
- Primary（蓝色）- 默认
- Secondary（紫色）
- Error（红色）
- Warning（橙色）
- Info（浅蓝）
- Success（绿色）

## 尺寸规范

- 默认 Radio 大小：20px
- 标签与 Radio 间距：8px
- 禁用状态透明度：0.38
- 错误状态颜色：Error 颜色方案

## 布局规范

### 垂直布局
- Radio 之间间距：8px
- 左对齐

### 水平布局
- Radio 之间间距：16px
- 垂直居中

## 验证标准

1. 编译成功
2. 在 Demo 中正确显示
3. 支持所有交互功能
4. 支持所有视觉样式
5. 与 MUI 设计一致