# Radio 组件实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 创建 MUI 风格的 Radio 和 RadioGroup 组件

**Architecture:** 基于 TDSCustomSkControl 基类，创建 TDSkRadio 和 TDSkRadioGroup 组件，实现单选按钮功能

**Tech Stack:** Delphi, VCL, Skia

---

## 文件结构映射

**修改文件：**
- `Sources/SkiaVclControls.Types.pas` - 添加新枚举类型
- `Sources/SkiaVclControls.Register.pas` - 注册新组件
- `SkiaVclControls.dpk` - 添加新单元

**新建文件：**
- `Sources/SkiaVclControls.Radio.pas` - TDSkRadio 组件
- `Sources/SkiaVclControls.RadioGroup.pas` - TDSkRadioGroup 组件
- `Demo/Radio/RadioDemo.dpr` - 演示程序
- `Demo/Radio/RadioMainForm.pas` - 演示窗口
- `Demo/Radio/RadioMainForm.dfm` - 演示窗口布局

---

## 任务 1：添加类型定义

**文件：**
- Modify: `Sources/SkiaVclControls.Types.pas`

- [ ] **步骤 1：添加 Radio 标签放置枚举**

在 `TDSkPanelStyle` 枚举之后添加：

```pascal
{ Radio 标签放置 }
TDSkRadioLabelPlacement = (
  rlpTop,     // 标签在上
  rlpBottom,  // 标签在下
  rlpLeft,    // 标签在左
  rlpRight    // 标签在右（默认）
);

{ RadioGroup 布局方向 }
TDSkRadioGroupOrientation = (
  rgoVertical,   // 垂直排列（默认）
  rgoHorizontal  // 水平排列
);
```

- [ ] **步骤 2：验证编译**

运行：`E:\temp\Dcc32cfg\delphi-compiler.exe E:\temp\SkiaControls\SkiaVclControls.dproj --config=Debug`
预期：编译成功，无错误

---

## 任务 2：创建 TDSkRadio 组件

**文件：**
- Create: `Sources/SkiaVclControls.Radio.pas`

- [ ] **步骤 1：创建单元文件**

```pascal
unit SkiaVclControls.Radio;

interface

uses
  System.Classes, System.SysUtils, System.Types, System.UITypes, System.Math,
  Vcl.Controls, Vcl.Graphics, Vcl.Skia, System.Skia,
  Winapi.Messages, Winapi.Windows,
  SkiaVclControls.Types, SkiaVclControls.Base;

type
  TDSkRadio = class(TDSCustomSkControl)
  private
    FChecked: Boolean;
    FCaption: string;
    FLabelPlacement: TDSkRadioLabelPlacement;
    FColorScheme: TDSkMUIColorScheme;
    FRadioSize: Single;
    FFont: TFont;
    FError: Boolean;
    FMouseIsDown: Boolean;
    FOnCheckChanged: TNotifyEvent;
    procedure SetChecked(Value: Boolean);
    procedure SetCaption(const Value: string);
    procedure SetLabelPlacement(Value: TDSkRadioLabelPlacement);
    procedure SetColorScheme(Value: TDSkMUIColorScheme);
    procedure SetRadioSize(Value: Single);
    procedure SetFont(Value: TFont);
    procedure SetError(Value: Boolean);
    procedure FontChanged(Sender: TObject);
    procedure CMEnabledChanged(var Message: TMessage); message CM_ENABLEDCHANGED;
  protected
    procedure Draw(const ACanvas: ISkCanvas; const ADest: TRectF; const AOpacity: Single); override;
    procedure DrawRadio(const ACanvas: ISkCanvas; const ADest: TRectF);
    procedure DrawLabel(const ACanvas: ISkCanvas; const ADest: TRectF);
    procedure MouseDown(Button: TMouseButton; Shift: TShiftState; X, Y: Integer); override;
    procedure MouseUp(Button: TMouseButton; Shift: TShiftState; X, Y: Integer); override;
    procedure KeyDown(var Key: Word; Shift: TShiftState); override;
    procedure Click; override;
    procedure UpdateCheckedState;
  public
    constructor Create(AOwner: TComponent); override;
    destructor Destroy; override;
    procedure Toggle;
  published
    property Checked: Boolean read FChecked write SetChecked default False;
    property Caption: string read FCaption write SetCaption;
    property LabelPlacement: TDSkRadioLabelPlacement read FLabelPlacement write SetLabelPlacement default rlpRight;
    property ColorScheme: TDSkMUIColorScheme read FColorScheme write SetColorScheme default muiPrimary;
    property RadioSize: Single read FRadioSize write SetRadioSize;
    property Font: TFont read FFont write SetFont;
    property Error: Boolean read FError write SetError default False;
    property OnCheckChanged: TNotifyEvent read FOnCheckChanged write FOnCheckChanged;
    property Enabled;
    property Visible;
    property OnClick;
    property OnEnter;
    property OnExit;
  end;

implementation

{ TDSkRadio }

constructor TDSkRadio.Create(AOwner: TComponent);
begin
  inherited Create(AOwner);
  FChecked := False;
  FCaption := '';
  FLabelPlacement := rlpRight;
  FColorScheme := muiPrimary;
  FRadioSize := 20;
  FFont := TFont.Create;
  FFont.OnChange := FontChanged;
  FError := False;
  FMouseIsDown := False;
  Width := 120;
  Height := 24;
  TabStop := True;
end;

destructor TDSkRadio.Destroy;
begin
  FFont.Free;
  inherited;
end;

procedure TDSkRadio.SetChecked(Value: Boolean);
begin
  if FChecked <> Value then
  begin
    FChecked := Value;
    UpdateCheckedState;
    Redraw;
    if Assigned(FOnCheckChanged) then
      FOnCheckChanged(Self);
  end;
end;

procedure TDSkRadio.SetCaption(const Value: string);
begin
  if FCaption <> Value then
  begin
    FCaption := Value;
    Redraw;
  end;
end;

procedure TDSkRadio.SetLabelPlacement(Value: TDSkRadioLabelPlacement);
begin
  if FLabelPlacement <> Value then
  begin
    FLabelPlacement := Value;
    Redraw;
  end;
end;

procedure TDSkRadio.SetColorScheme(Value: TDSkMUIColorScheme);
begin
  if FColorScheme <> Value then
  begin
    FColorScheme := Value;
    Redraw;
  end;
end;

procedure TDSkRadio.SetRadioSize(Value: Single);
begin
  if FRadioSize <> Value then
  begin
    FRadioSize := Value;
    Redraw;
  end;
end;

procedure TDSkRadio.SetFont(Value: TFont);
begin
  FFont.Assign(Value);
end;

procedure TDSkRadio.SetError(Value: Boolean);
begin
  if FError <> Value then
  begin
    FError := Value;
    Redraw;
  end;
end;

procedure TDSkRadio.FontChanged(Sender: TObject);
begin
  Redraw;
end;

procedure TDSkRadio.CMEnabledChanged(var Message: TMessage);
begin
  inherited;
  Redraw;
end;

procedure TDSkRadio.Draw(const ACanvas: ISkCanvas; const ADest: TRectF; const AOpacity: Single);
begin
  inherited;
  DrawRadio(ACanvas, ADest);
  DrawLabel(ACanvas, ADest);
end;

procedure TDSkRadio.DrawRadio(const ACanvas: ISkCanvas; const ADest: TRectF);
var
  LCenter: TPointF;
  LRadius: Single;
  LPaint: ISkPaint;
  LColor: TAlphaColor;
begin
  LRadius := FRadioSize / 2;
  case FLabelPlacement of
    rlpRight: LCenter := PointF(ADest.Left + LRadius, ADest.Top + ADest.Height / 2);
    rlpLeft: LCenter := PointF(ADest.Right - LRadius, ADest.Top + ADest.Height / 2);
    rlpTop: LCenter := PointF(ADest.Left + ADest.Width / 2, ADest.Bottom - LRadius);
    rlpBottom: LCenter := PointF(ADest.Left + ADest.Width / 2, ADest.Top + LRadius);
  end;

  // 确定颜色
  if not Enabled then
    LColor := $FFBDBDBD
  else if FError then
    LColor := $FFD32F2F
  else
  begin
    case FColorScheme of
      muiSecondary: LColor := $FF9C27B0;
      muiError: LColor := $FFD32F2F;
      muiWarning: LColor := $FFED6C02;
      muiInfo: LColor := $FF0288D1;
      muiSuccess: LColor := $FF2E7D32;
    else
      LColor := $FF1976D2; // Primary
    end;
  end;

  LPaint := TSkPaint.Create;
  LPaint.AntiAlias := True;

  // 绘制外圈
  LPaint.Style := TSkPaintStyle.Stroke;
  LPaint.StrokeWidth := 2;
  LPaint.Color := LColor;
  ACanvas.DrawCircle(LCenter, LRadius - 1, LPaint);

  // 绘制内圈（选中状态）
  if FChecked then
  begin
    LPaint.Style := TSkPaintStyle.Fill;
    ACanvas.DrawCircle(LCenter, LRadius * 0.5, LPaint);
  end;
end;

procedure TDSkRadio.DrawLabel(const ACanvas: ISkCanvas; const ADest: TRectF);
var
  LFont: ISkFont;
  LTypeface: ISkTypeface;
  LFontStyle: TSkFontStyle;
  LPaint: ISkPaint;
  LX, LY: Single;
  LTextW, LTextH: Single;
  LFontSize: Single;
begin
  if FCaption = '' then Exit;

  // 确定字体样式
  if (fsBold in FFont.Style) and (fsItalic in FFont.Style) then
    LFontStyle := TSkFontStyle.BoldItalic
  else if fsBold in FFont.Style then
    LFontStyle := TSkFontStyle.Bold
  else if fsItalic in FFont.Style then
    LFontStyle := TSkFontStyle.Italic
  else
    LFontStyle := TSkFontStyle.Normal;

  LTypeface := TSkTypeface.MakeFromName(FFont.Name, LFontStyle);
  LFontSize := FontSizeToPixels(FFont);
  LFont := TSkFont.Create(LTypeface, LFontSize);

  LTextW := LFont.MeasureText(FCaption);
  LTextH := LFontSize;

  LPaint := TSkPaint.Create;
  LPaint.AntiAlias := True;
  LPaint.Color := Font.Color;

  // 根据标签放置确定位置
  case FLabelPlacement of
    rlpRight: begin
      LX := ADest.Left + FRadioSize + 8;
      LY := ADest.Top + (ADest.Height - LTextH) / 2 + LTextH;
    end;
    rlpLeft: begin
      LX := ADest.Right - FRadioSize - 8 - LTextW;
      LY := ADest.Top + (ADest.Height - LTextH) / 2 + LTextH;
    end;
    rlpTop: begin
      LX := ADest.Left + (ADest.Width - LTextW) / 2;
      LY := ADest.Bottom - FRadioSize - 8;
    end;
    rlpBottom: begin
      LX := ADest.Left + (ADest.Width - LTextW) / 2;
      LY := ADest.Top + FRadioSize + 8 + LTextH;
    end;
  end;

  ACanvas.DrawText(FCaption, LX, LY, LFont, LPaint);
end;

procedure TDSkRadio.MouseDown(Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
begin
  inherited;
  FMouseIsDown := True;
end;

procedure TDSkRadio.MouseUp(Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
begin
  inherited;
  if FMouseIsDown then
  begin
    FMouseIsDown := False;
    Toggle;
  end;
end;

procedure TDSkRadio.KeyDown(var Key: Word; Shift: TShiftState);
begin
  inherited;
  if Key = VK_SPACE then
    Toggle;
end;

procedure TDSkRadio.Click;
begin
  inherited;
end;

procedure TDSkRadio.Toggle;
begin
  Checked := not Checked;
end;

procedure TDSkRadio.UpdateCheckedState;
begin
  // 如果在 RadioGroup 中，通知 Group 更新
  if Parent is TDSkRadioGroup then
    TDSkRadioGroup(Parent).UpdateSelection(Self);
end;

end.
```

- [ ] **步骤 2：验证编译**

运行：`E:\temp\Dcc32cfg\delphi-compiler.exe E:\temp\SkiaControls\SkiaVclControls.dproj --config=Debug`
预期：编译成功，无错误

---

## 任务 3：创建 TDSkRadioGroup 组件

**文件：**
- Create: `Sources/SkiaVclControls.RadioGroup.pas`

- [ ] **步骤 1：创建单元文件**

```pascal
unit SkiaVclControls.RadioGroup;

interface

uses
  System.Classes, System.SysUtils, System.Types, System.UITypes, System.Math,
  Vcl.Controls, Vcl.Graphics, Vcl.Skia, System.Skia,
  Winapi.Messages, Winapi.Windows,
  SkiaVclControls.Types, SkiaVclControls.Base, SkiaVclControls.Radio;

type
  TDSkRadioGroupItemClickEvent = procedure(Sender: TObject; RadioIndex: Integer) of object;

  TDSkRadioGroup = class(TDSCustomSkControl)
  private
    FOrientation: TDSkRadioGroupOrientation;
    FItemIndex: Integer;
    FItems: TStrings;
    FColorScheme: TDSkMUIColorScheme;
    FLabelPlacement: TDSkRadioLabelPlacement;
    FExclusive: Boolean;
    FLoading: Boolean;
    FUpdating: Boolean;
    FOnItemClick: TDSkRadioGroupItemClickEvent;
    procedure SetOrientation(Value: TDSkRadioGroupOrientation);
    procedure SetItemIndex(Value: Integer);
    procedure SetItems(Value: TStrings);
    procedure SetColorScheme(Value: TDSkMUIColorScheme);
    procedure SetLabelPlacement(Value: TDSkRadioLabelPlacement);
    procedure SetExclusive(Value: Boolean);
    procedure ItemsChanged(Sender: TObject);
    procedure CreateRadioButtons;
    procedure UpdateRadioStates;
    procedure WMDSkRadioGroupClick(var Message: TMessage); message WM_USER + 201;
    procedure CMControlChange(var Message: TCMControlChange); message CM_CONTROLCHANGE;
  protected
    procedure AlignControls(AControl: TControl; var Rect: TRect); override;
    procedure Draw(const ACanvas: ISkCanvas; const ADest: TRectF; const AOpacity: Single); override;
    procedure Loaded; override;
    procedure Resize; override;
    procedure Notification(AComponent: TComponent; AOperation: TOperation); override;
  public
    constructor Create(AOwner: TComponent); override;
    destructor Destroy; override;
    function GetRadioCount: Integer;
    function GetRadio(Index: Integer): TDSkRadio;
    function IndexOfRadio(ARadio: TDSkRadio): Integer;
    procedure UpdateSelection(SelectedRadio: TDSkRadio);
    property RadioCount: Integer read GetRadioCount;
    property Radios[Index: Integer]: TDSkRadio read GetRadio;
  published
    property Orientation: TDSkRadioGroupOrientation read FOrientation write SetOrientation default rgoVertical;
    property ItemIndex: Integer read FItemIndex write SetItemIndex default -1;
    property Items: TStrings read FItems write SetItems;
    property ColorScheme: TDSkMUIColorScheme read FColorScheme write SetColorScheme default muiPrimary;
    property LabelPlacement: TDSkRadioLabelPlacement read FLabelPlacement write SetLabelPlacement default rlpRight;
    property Exclusive: Boolean read FExclusive write SetExclusive default True;
    property OnItemClick: TDSkRadioGroupItemClickEvent read FOnItemClick write FOnItemClick;
    property CornerRadius;
    property BackgroundColor;
    property BorderColor;
    property BorderWidth;
    property OnClick;
    property OnMouseEnter;
    property OnMouseLeave;
  end;

implementation

{ TDSkRadioGroup }

constructor TDSkRadioGroup.Create(AOwner: TComponent);
begin
  inherited Create(AOwner);
  FOrientation := rgoVertical;
  FItemIndex := -1;
  FItems := TStringList.Create;
  TStringList(FItems).OnChange := ItemsChanged;
  FColorScheme := muiPrimary;
  FLabelPlacement := rlpRight;
  FExclusive := True;
  FLoading := (csLoading in ComponentState) or
    ((AOwner <> nil) and (csLoading in AOwner.ComponentState));
  FUpdating := False;
  Width := 200;
  Height := 150;
  CornerRadius := 4;
  BackgroundColor := TAlphaColors.White;
  BorderColor := $33000000;
  BorderWidth := 1;
end;

destructor TDSkRadioGroup.Destroy;
begin
  FItems.Free;
  inherited;
end;

procedure TDSkRadioGroup.SetOrientation(Value: TDSkRadioGroupOrientation);
begin
  if FOrientation <> Value then
  begin
    FOrientation := Value;
    if not FLoading then
    begin
      Realign;
      Redraw;
    end;
  end;
end;

procedure TDSkRadioGroup.SetItemIndex(Value: Integer);
begin
  if Value < -1 then Value := -1;
  if Value >= GetRadioCount then Value := -1;
  if FItemIndex <> Value then
  begin
    FItemIndex := Value;
    UpdateRadioStates;
    if Assigned(FOnItemClick) then
      FOnItemClick(Self, FItemIndex);
  end;
end;

procedure TDSkRadioGroup.SetItems(Value: TStrings);
begin
  FItems.Assign(Value);
end;

procedure TDSkRadioGroup.SetColorScheme(Value: TDSkMUIColorScheme);
begin
  if FColorScheme <> Value then
  begin
    FColorScheme := Value;
    if not FLoading then
      CreateRadioButtons;
  end;
end;

procedure TDSkRadioGroup.SetLabelPlacement(Value: TDSkRadioLabelPlacement);
begin
  if FLabelPlacement <> Value then
  begin
    FLabelPlacement := Value;
    if not FLoading then
      CreateRadioButtons;
  end;
end;

procedure TDSkRadioGroup.SetExclusive(Value: Boolean);
begin
  if FExclusive <> Value then
  begin
    FExclusive := Value;
    UpdateRadioStates;
  end;
end;

procedure TDSkRadioGroup.ItemsChanged(Sender: TObject);
begin
  if not FLoading then
    CreateRadioButtons;
end;

procedure TDSkRadioGroup.CreateRadioButtons;
var
  i: Integer;
  LRadio: TDSkRadio;
begin
  // 删除现有 Radio 按钮
  for i := ControlCount - 1 downto 0 do
    if Controls[i] is TDSkRadio then
      Controls[i].Free;

  // 创建新的 Radio 按钮
  FUpdating := True;
  try
    for i := 0 to FItems.Count - 1 do
    begin
      LRadio := TDSkRadio.Create(Owner);
      LRadio.Name := 'Radio' + IntToStr(i + 1);
      LRadio.Parent := Self;
      LRadio.Caption := FItems[i];
      LRadio.ColorScheme := FColorScheme;
      LRadio.LabelPlacement := FLabelPlacement;
      LRadio.Checked := i = FItemIndex;
    end;
  finally
    FUpdating := False;
  end;

  Realign;
  Redraw;
end;

procedure TDSkRadioGroup.UpdateRadioStates;
var
  i: Integer;
  LRadio: TDSkRadio;
begin
  if FUpdating then Exit;
  FUpdating := True;
  try
    for i := 0 to GetRadioCount - 1 do
    begin
      LRadio := GetRadio(i);
      if LRadio <> nil then
        LRadio.Checked := i = FItemIndex;
    end;
  finally
    FUpdating := False;
  end;
end;

procedure TDSkRadioGroup.UpdateSelection(SelectedRadio: TDSkRadio);
var
  Idx: Integer;
begin
  Idx := IndexOfRadio(SelectedRadio);
  if Idx < 0 then Exit;

  if FExclusive then
  begin
    FItemIndex := Idx;
    UpdateRadioStates;
  end;

  if Assigned(FOnItemClick) then
    FOnItemClick(Self, FItemIndex);
end;

function TDSkRadioGroup.GetRadioCount: Integer;
var
  i: Integer;
begin
  Result := 0;
  for i := 0 to ControlCount - 1 do
    if Controls[i] is TDSkRadio then
      Inc(Result);
end;

function TDSkRadioGroup.GetRadio(Index: Integer): TDSkRadio;
var
  i, LIndex: Integer;
begin
  Result := nil;
  LIndex := 0;
  for i := 0 to ControlCount - 1 do
    if Controls[i] is TDSkRadio then
    begin
      if LIndex = Index then
        Exit(TDSkRadio(Controls[i]));
      Inc(LIndex);
    end;
end;

function TDSkRadioGroup.IndexOfRadio(ARadio: TDSkRadio): Integer;
var
  i, LIndex: Integer;
begin
  Result := -1;
  LIndex := 0;
  for i := 0 to ControlCount - 1 do
    if Controls[i] is TDSkRadio then
    begin
      if Controls[i] = ARadio then
        Exit(LIndex);
      Inc(LIndex);
    end;
end;

procedure TDSkRadioGroup.AlignControls(AControl: TControl; var Rect: TRect);
var
  Count, i: Integer;
  LRadio: TDSkRadio;
  X, Y, W, H: Integer;
  AvailableW, AvailableH: Integer;
begin
  inherited AlignControls(AControl, Rect);
  if FUpdating then Exit;

  Count := GetRadioCount;
  if Count = 0 then Exit;

  FUpdating := True;
  try
    AvailableW := Max(0, ClientWidth);
    AvailableH := Max(0, ClientHeight);

    if FOrientation = rgoVertical then
    begin
      Y := 0;
      W := AvailableW;
      H := 24; // 固定高度

      for i := 0 to Count - 1 do
      begin
        LRadio := GetRadio(i);
        if LRadio = nil then Continue;
        LRadio.SetBounds(0, Y, W, H);
        Y := Y + H + 8; // 8px 间距
      end;
    end
    else
    begin
      X := 0;
      H := AvailableH;
      W := 120; // 固定宽度

      for i := 0 to Count - 1 do
      begin
        LRadio := GetRadio(i);
        if LRadio = nil then Continue;
        LRadio.SetBounds(X, 0, W, H);
        X := X + W + 16; // 16px 间距
      end;
    end;
  finally
    FUpdating := False;
  end;
end;

procedure TDSkRadioGroup.Draw(const ACanvas: ISkCanvas; const ADest: TRectF; const AOpacity: Single);
begin
  inherited;
end;

procedure TDSkRadioGroup.Loaded;
begin
  inherited;
  FLoading := False;
  CreateRadioButtons;
end;

procedure TDSkRadioGroup.Resize;
begin
  inherited;
  if not FLoading then
    Realign;
end;

procedure TDSkRadioGroup.Notification(AComponent: TComponent; AOperation: TOperation);
begin
  inherited;
  if (AOperation = opRemove) and (AComponent is TDSkRadio) and not (csDestroying in ComponentState) then
  begin
    if not FLoading then
    begin
      Realign;
      Redraw;
    end;
  end;
end;

procedure TDSkRadioGroup.WMDSkRadioGroupClick(var Message: TMessage);
begin
  if (TObject(Message.WParam) is TDSkRadio) and not FUpdating then
    UpdateSelection(TDSkRadio(Message.WParam));
end;

procedure TDSkRadioGroup.CMControlChange(var Message: TCMControlChange);
begin
  inherited;
  if Message.Control is TDSkRadio then
  begin
    if not FLoading then
    begin
      Realign;
      Redraw;
    end;
  end;
end;

end.
```

- [ ] **步骤 2：验证编译**

运行：`E:\temp\Dcc32cfg\delphi-compiler.exe E:\temp\SkiaControls\SkiaVclControls.dproj --config=Debug`
预期：编译成功，无错误

---

## 任务 4：注册组件

**文件：**
- Modify: `Sources/SkiaVclControls.Register.pas`
- Modify: `SkiaVclControls.dpk`

- [ ] **步骤 1：修改 Register 单元**

修改 `Sources/SkiaVclControls.Register.pas`：

```pascal
unit SkiaVclControls.Register;

interface

procedure Register;

implementation

uses
  System.Classes, SkiaVclControls.Button, SkiaVclControls.Panel,
  SkiaVclControls.ButtonGroup, SkiaVclControls.Radio, SkiaVclControls.RadioGroup;

procedure Register;
begin
  RegisterComponents('SkiaVclControls', [TDSkButton, TDSkPanel, TDSkButtonGroup, TDSkRadio, TDSkRadioGroup]);
end;

end.
```

- [ ] **步骤 2：修改包文件**

修改 `SkiaVclControls.dpk` 的 contains 部分：

```pascal
contains
  SkiaVclControls.Types in 'Sources\SkiaVclControls.Types.pas',
  SkiaVclControls.Base in 'Sources\SkiaVclControls.Base.pas',
  SkiaVclControls.Button in 'Sources\SkiaVclControls.Button.pas',
  SkiaVclControls.Panel in 'Sources\SkiaVclControls.Panel.pas',
  SkiaVclControls.ButtonGroup in 'Sources\SkiaVclControls.ButtonGroup.pas',
  SkiaVclControls.Radio in 'Sources\SkiaVclControls.Radio.pas',
  SkiaVclControls.RadioGroup in 'Sources\SkiaVclControls.RadioGroup.pas',
  SkiaVclControls.MUIHelper in 'Sources\SkiaVclControls.MUIHelper.pas',
  SkiaVclControls.Register in 'Sources\SkiaVclControls.Register.pas';
```

- [ ] **步骤 3：验证编译**

运行：`E:\temp\Dcc32cfg\delphi-compiler.exe E:\temp\SkiaControls\SkiaVclControls.dproj --config=Debug`
预期：编译成功，无错误

---

## 任务 5：创建 Demo

**文件：**
- Create: `Demo/Radio/RadioDemo.dpr`
- Create: `Demo/Radio/RadioMainForm.pas`
- Create: `Demo/Radio/RadioMainForm.dfm`

- [ ] **步骤 1：创建演示程序文件**

创建 `Demo/Radio/RadioDemo.dpr`：

```pascal
program RadioDemo;

uses
  Vcl.Forms,
  RadioMainForm in 'RadioMainForm.pas' {FormRadioDemo};

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TFormRadioDemo, FormRadioDemo);
  Application.Run;
end.
```

- [ ] **步骤 2：创建演示窗口单元**

创建 `Demo/Radio/RadioMainForm.pas`：

```pascal
unit RadioMainForm;

interface

uses
  System.Classes, System.SysUtils, System.UITypes,
  Vcl.Forms, Vcl.Controls, Vcl.StdCtrls, Vcl.ExtCtrls,
  SkiaVclControls.Types, SkiaVclControls.Radio, SkiaVclControls.RadioGroup;

type
  TFormRadioDemo = class(TForm)
    procedure FormCreate(Sender: TObject);
  private
    FRadioGroup: TDSkRadioGroup;
    FRadio1: TDSkRadio;
    FRadio2: TDSkRadio;
    FRadio3: TDSkRadio;
    procedure RadioGroupItemClick(Sender: TObject; RadioIndex: Integer);
  end;

var
  FormRadioDemo: TFormRadioDemo;

implementation

{$R *.dfm}

procedure TFormRadioDemo.FormCreate(Sender: TObject);
begin
  // 创建 RadioGroup
  FRadioGroup := TDSkRadioGroup.Create(Self);
  FRadioGroup.Parent := Self;
  FRadioGroup.SetBounds(20, 20, 200, 150);
  FRadioGroup.Items.Add('Option 1');
  FRadioGroup.Items.Add('Option 2');
  FRadioGroup.Items.Add('Option 3');
  FRadioGroup.ItemIndex := 0;
  FRadioGroup.OnItemClick := RadioGroupItemClick;

  // 创建独立 Radio
  FRadio1 := TDSkRadio.Create(Self);
  FRadio1.Parent := Self;
  FRadio1.SetBounds(20, 200, 200, 24);
  FRadio1.Caption := 'Standalone Radio 1';
  FRadio1.Checked := True;

  FRadio2 := TDSkRadio.Create(Self);
  FRadio2.Parent := Self;
  FRadio2.SetBounds(20, 230, 200, 24);
  FRadio2.Caption := 'Standalone Radio 2';

  FRadio3 := TDSkRadio.Create(Self);
  FRadio3.Parent := Self;
  FRadio3.SetBounds(20, 260, 200, 24);
  FRadio3.Caption := 'Standalone Radio 3';
  FRadio3.Enabled := False;
end;

procedure TFormRadioDemo.RadioGroupItemClick(Sender: TObject; RadioIndex: Integer);
begin
  ShowMessage('Selected: ' + IntToStr(RadioIndex));
end;

end.
```

- [ ] **步骤 3：创建演示窗口布局**

创建 `Demo/Radio/RadioMainForm.dfm`：

```
object FormRadioDemo: TFormRadioDemo
  Left = 0
  Top = 0
  Caption = 'Radio Demo'
  ClientHeight = 400
  ClientWidth = 600
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
end
```

- [ ] **步骤 4：验证编译**

运行：`E:\temp\Dcc32cfg\delphi-compiler.exe E:\temp\SkiaControls\Demo\Radio\RadioDemo.dproj --config=Debug`
预期：编译成功，无错误

---

## 任务 6：测试验证

- [ ] **步骤 1：编译主包**

运行：`E:\temp\Dcc32cfg\delphi-compiler.exe E:\temp\SkiaControls\SkiaVclControls.dproj --config=Debug`
预期：编译成功，无错误

- [ ] **步骤 2：编译 Demo**

运行：`E:\temp\Dcc32cfg\delphi-compiler.exe E:\temp\SkiaControls\Demo\Radio\RadioDemo.dproj --config=Debug`
预期：编译成功，无错误

- [ ] **步骤 3：运行 Demo 测试**

运行生成的可执行文件，验证：
1. RadioGroup 正确显示三个选项
2. 点击 Radio 可以选中
3. 选中状态正确显示
4. 禁用状态正确显示

- [ ] **步骤 4：提交更改**

```bash
git add Sources/SkiaVclControls.Types.pas Sources/SkiaVclControls.Radio.pas Sources/SkiaVclControls.RadioGroup.pas Sources/SkiaVclControls.Register.pas SkiaVclControls.dpk Demo/Radio/
git commit -m "feat: 添加 MUI 风格的 Radio 和 RadioGroup 组件"
```

---

## 自审检查

1. **规格覆盖**：所有设计要求都已覆盖
2. **占位符扫描**：无 TBD、TODO 或模糊需求
3. **类型一致性**：函数签名和属性名称保持一致

---

## 执行选项

**计划完成并保存到 `docs/superpowers/plans/2026-06-04-Radio-Component.md`。两种执行选项：**

**1. Subagent-Driven (推荐)** - 我为每个任务调度一个新的子代理，任务间进行审查，快速迭代

**2. Inline Execution** - 在当前会话中使用 executing-plans 执行任务，批量执行并设置检查点

**选择哪种方式？**