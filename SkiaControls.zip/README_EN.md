# SkiaVclControls

Material Design VCL Controls based on Delphi built-in Skia

[![Delphi](https://img.shields.io/badge/Delphi-11+-red.svg)](https://www.embarcadero.com/products/delphi)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

[中文](README.md) | **English**

---

## Features

- **Material Design 3** style
- **Skia Rendering** - High-quality graphics with Delphi built-in Skia support
- **DPI-Aware** - Perfect support for high-DPI displays
- **Smooth Animations** - Built-in hover and click animations
- **MUI Themes** - Built-in Material-UI color schemes
- **Chinese Support** - Auto-detect and use system Chinese fonts
- **Transparent Rendering** - Alpha channel transparency, parent-child compositing
- **Disabled State** - Complete Enabled/Disabled visual state support

---

## Controls

### Basic Controls

| Control | Description |
|---------|-------------|
| `TDSkButton` | Material Design button with multiple styles, animations and icons |
| `TDSkPanel` | Material Design panel with various container styles and hover effects |
| `TDSkButtonGroup` | Button group for unified style and state management |

### Selection Controls

| Control | Description |
|---------|-------------|
| `TDSkRadio` | Radio button, MUI style, transparent background |
| `TDSkRadioGroup` | Radio button group, self-drawing mode, with caption support |
| `TDSkCheckbox` | Checkbox with tri-state support (unchecked/checked/indeterminate) |
| `TDSkCheckboxGroup` | Checkbox group, supports multi-select/single-select mode |
| `TDSkSwitch` | Switch control, track + thumb sliding switch |
| `TDSkSwitchGroup` | Switch group, supports multi-select/single-select mode |
| `TDSkSelect` | Dropdown selector, supports Outlined/Filled/Underline variants |

### Input Controls

| Control | Description |
|---------|-------------|
| `TDSkEdit` | Text editor with floating label, selection, password mode |

### Feedback Controls

| Control | Description |
|---------|-------------|
| `TDSkSlider` | Slider, supports continuous/discrete/range/vertical sliders |
| `TDSkProgressBar` | Linear progress bar, supports determinate/indeterminate/buffer variants |
| `TDSkCircularProgress` | Circular progress bar, supports determinate/indeterminate variants |
| `TDSkSnackbar` | Snackbar, short message sliding in from bottom, with auto-hide and action button |

### Navigation Controls

| Control | Description |
|---------|-------------|
| `TDSkStepper` | Stepper, supports horizontal/vertical, linear/non-linear modes |
| `TDSkTabs` | Tabs, supports standard/bottom navigation styles, horizontal/vertical |

---

## Requirements

- **Delphi 11 Alexandria** or higher (Skia support required)
- **Windows** platform
- **Skia Package** - Select Skia during Delphi installation

---

## Installation

### Method 1: Install via Delphi IDE

1. Clone or download this repository
2. Open `SkiaVclControls.dpk` (design-time package)
3. Right-click `SkiaVclControls.bpl` in Project Manager
4. Select **Compile**, then **Install**
5. Components will appear in the **SkiaVclControls** tab

### Method 2: Use Build Script

```batch
build.bat
```

Then manually install the generated `SkiaVclControls.bpl`

---

## Quick Start

### TDSkButton Example

```delphi
uses
  SkiaVclControls.Button, SkiaVclControls.Types;

procedure TForm1.FormCreate(Sender: TObject);
begin
  Button1 := TDSkButton.Create(Self);
  Button1.Parent := Self;
  Button1.ButtonText := 'Click Me';
  Button1.MUIColorScheme := muiPrimary;
  Button1.MUIStyle := muiContained;
  Button1.HoverEffect := heRipple;
end;
```

### TDSkPanel Example

```delphi
uses
  SkiaVclControls.Panel, SkiaVclControls.Types;

procedure TForm1.FormCreate(Sender: TObject);
begin
  Panel1 := TDSkPanel.Create(Self);
  Panel1.Parent := Self;
  Panel1.Caption := 'Title';
  Panel1.PanelStyle := psOutlined;
  Panel1.CornerRadius := 12;
  Panel1.HoverEnabled := True;
end;
```

### TDSkSnackbar Example

```delphi
uses
  SkiaVclControls.Snackbar, SkiaVclControls.Types;

// Quick show
TDSkSnackbar.ShowSnackbar(Self, 'Operation completed!', snkSuccess);

// Custom configuration
Snackbar1.Message := 'Item has been deleted';
Snackbar1.Severity := snkNone;
Snackbar1.Position := spBottomCenter;
Snackbar1.AutoHideDuration := 6000;
Snackbar1.ActionText := 'UNDO';
Snackbar1.Show;
```

### TDSkSelect Example

```delphi
uses
  SkiaVclControls.Select, SkiaVclControls.Types;

procedure TForm1.FormCreate(Sender: TObject);
begin
  Select1 := TDSkSelect.Create(Self);
  Select1.Parent := Self;
  Select1.Items.Add('Option 1');
  Select1.Items.Add('Option 2');
  Select1.Items.Add('Option 3');
  Select1.Label_ := 'Please select';
  Select1.Variant := svOutlined;
  Select1.ColorScheme := muiPrimary;
end;
```

---

## Project Structure

```
SkiaVclControls/
├── Sources/                         # Source code
│   ├── SkiaVclControls.Types.pas        # Shared types, enumerations
│   ├── SkiaVclControls.Base.pas         # Base class
│   ├── SkiaVclControls.Button.pas       # Button
│   ├── SkiaVclControls.Panel.pas        # Panel
│   ├── SkiaVclControls.ButtonGroup.pas  # Button group
│   ├── SkiaVclControls.Radio.pas        # Radio button
│   ├── SkiaVclControls.RadioGroup.pas   # Radio button group
│   ├── SkiaVclControls.Checkbox.pas     # Checkbox
│   ├── SkiaVclControls.CheckboxGroup.pas # Checkbox group
│   ├── SkiaVclControls.Switch.pas       # Switch
│   ├── SkiaVclControls.SwitchGroup.pas  # Switch group
│   ├── SkiaVclControls.Select.pas       # Dropdown selector
│   ├── SkiaVclControls.Edit.pas         # Text editor
│   ├── SkiaVclControls.Slider.pas       # Slider
│   ├── SkiaVclControls.ProgressBar.pas  # Linear progress bar
│   ├── SkiaVclControls.CircularProgress.pas # Circular progress bar
│   ├── SkiaVclControls.Stepper.pas      # Stepper
│   ├── SkiaVclControls.Tabs.pas         # Tabs
│   ├── SkiaVclControls.Snackbar.pas     # Snackbar
│   ├── SkiaVclControls.MUIHelper.pas    # MUI color helper
│   └── SkiaVclControls.Register.pas     # Component registration
├── Demo/                            # Demo applications
│   ├── Button/                        # Button demo
│   ├── Panel/                         # Panel demo
│   ├── ButtonGroup/                   # Button group demo
│   ├── Radio/                         # Radio button demo
│   ├── Slider/                        # Slider demo
│   ├── Checkbox/                      # Checkbox demo
│   ├── Switch/                        # Switch demo
│   ├── Select/                        # Dropdown selector demo
│   ├── Edit/                          # Text editor demo
│   ├── Progress/                      # Progress bar demo
│   ├── Stepper/                       # Stepper demo
│   ├── Tabs/                          # Tabs demo
│   └── Snackbar/                      # Snackbar demo
├── SkiaVclControls.dpk              # Design-time package
└── build.bat                        # Build script
```

---

## Screenshots

### TDSkButton Demo
![Button Demo](screenshots/button-demo.png)

### TDSkPanel Demo
![Panel Demo](screenshots/panel-demo.png)

### TDSkButtonGroup Demo
![ButtonGroup Demo](screenshots/buttongroup-demo.png)

### TDSkSelect Demo
![Select Demo](screenshots/select-demo.png)

### TDSkSnackbar Demo
![Snackbar Demo](screenshots/snackbar-demo.png)

---

## Contributing

Issues and Pull Requests are welcome!

---

## License

This project is licensed under the [MIT](LICENSE) License

---

## Acknowledgements

- [Skia](https://skia.org/) - Powerful 2D graphics library
- [Material Design](https://m3.material.io/) - Google Material Design 3
- [Material-UI](https://mui.com/) - React UI component library (color reference)
