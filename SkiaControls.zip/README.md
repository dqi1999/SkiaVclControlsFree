# SkiaVclControls

基于 Delphi 内置 Skia 的 Material Design VCL 控件库

[![Delphi](https://img.shields.io/badge/Delphi-11+-red.svg)](https://www.embarcadero.com/products/delphi)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

**[English](README_EN.md)** | 中文

---

## 特性

- **Material Design 3** 风格设计
- **Skia 渲染** - 利用 Delphi 内置 Skia 支持，高质量图形渲染
- **DPI 感知** - 完美支持高 DPI 显示
- **流畅动画** - 内置悬停、点击动画效果（Ripple/Glow/ScaleUp）
- **MUI 主题** - 内置 Material-UI 配色方案
- **中文支持** - 自动检测并使用系统中文字体
- **透明渲染** - 支持 Alpha 通道透明度，父子控件透明合成
- **禁用状态** - 完整的 Enabled 禁用状态视觉支持
- **设计期预览** - 完整的设计期可视化编辑支持

---

## 控件列表

### 基础控件

| 控件 | 说明 |
|------|------|
| `TDSkButton` | Material Design 按钮，支持 MUI 配色、Ripple 动画、多种样式和图标 |
| `TDSkPanel` | Material Design 面板，支持多种容器样式和悬停效果 |
| `TDSkButtonGroup` | 按钮组控件，统一管理一组按钮的样式和状态 |

### 选择控件

| 控件 | 说明 |
|------|------|
| `TDSkRadio` | 单选按钮，MUI 风格，支持透明背景 |
| `TDSkRadioGroup` | 单选按钮组，自绘模式，支持标题显示 |
| `TDSkCheckbox` | 复选框，支持三态（未选中/选中/不确定） |
| `TDSkCheckboxGroup` | 复选框组，支持多选/单选模式 |
| `TDSkSwitch` | 开关控件，轨道+滑块滑动开关 |
| `TDSkSwitchGroup` | 开关组，支持多选/单选模式 |
| `TDSkSelect` | 下拉选择器，支持 Outlined/Filled/Underline 三种变体 |

### 输入控件

| 控件 | 说明 |
|------|------|
| `TDSkEdit` | 文本编辑框，支持浮动标签、选区操作、密码模式 |

### 反馈控件

| 控件 | 说明 |
|------|------|
| `TDSkSlider` | 滑块控件，支持连续/间续/范围/垂直滑块 |
| `TDSkProgressBar` | 线性进度条，支持定量/不定量/缓冲三种变体 |
| `TDSkCircularProgress` | 环形进度条，支持定量/不定量两种变体 |
| `TDSkSnackbar` | 消息条，从屏幕底部滑入的简短消息，支持自动隐藏和操作按钮 |

### 导航控件

| 控件 | 说明 |
|------|------|
| `TDSkStepper` | 步骤条，支持水平/垂直方向、线性/非线性模式 |
| `TDSkTabs` | 选项卡，支持标准/底部导航样式，水平/垂直方向 |

---

## 系统要求

- **Delphi 11 Alexandria** 或更高版本（需内置 Skia 支持）
- **Windows** 平台
- **Skia 包** - Delphi 安装时需选择 Skia 支持

---

## 安装

### 方法一：通过 Delphi IDE 安装

1. 克隆或下载本仓库到本地
2. 打开 `SkiaVclControls.dpk`（设计时包）
3. 在 Project Manager 中右键点击 `SkiaVclControls.bpl`
4. 选择 **Compile**，然后选择 **Install**
5. 控件将出现在组件面板的 **SkiaVclControls** 页签中

### 方法二：使用编译脚本

```batch
build.bat
```

然后手动安装生成的 `SkiaVclControls.bpl`

---

## 快速开始

### TDSkButton 使用示例

```delphi
uses
  SkiaVclControls.Button, SkiaVclControls.Types;

procedure TForm1.FormCreate(Sender: TObject);
begin
  Button1 := TDSkButton.Create(Self);
  Button1.Parent := Self;
  Button1.ButtonText := '点击我';
  Button1.MUIColorScheme := muiPrimary;
  Button1.MUIStyle := muiContained;
  Button1.HoverEffect := heRipple;  // MUI 风格 Ripple 动画
end;
```

### TDSkPanel 使用示例

```delphi
uses
  SkiaVclControls.Panel, SkiaVclControls.Types;

procedure TForm1.FormCreate(Sender: TObject);
begin
  Panel1 := TDSkPanel.Create(Self);
  Panel1.Parent := Self;
  Panel1.Caption := '标题';
  Panel1.PanelStyle := psOutlined;
  Panel1.CornerRadius := 12;
  Panel1.HoverEnabled := True;
end;
```

### TDSkSnackbar 使用示例

```delphi
uses
  SkiaVclControls.Snackbar, SkiaVclControls.Types;

// 快速显示
TDSkSnackbar.ShowSnackbar(Self, '操作成功！', snkSuccess);

// 自定义配置
Snackbar1.Message := '项目已删除';
Snackbar1.Severity := snkNone;
Snackbar1.Position := spBottomCenter;
Snackbar1.AutoHideDuration := 6000;
Snackbar1.ActionText := '撤销';
Snackbar1.Show;
```

### TDSkSelect 使用示例

```delphi
uses
  SkiaVclControls.Select, SkiaVclControls.Types;

procedure TForm1.FormCreate(Sender: TObject);
begin
  Select1 := TDSkSelect.Create(Self);
  Select1.Parent := Self;
  Select1.Items.Add('选项一');
  Select1.Items.Add('选项二');
  Select1.Items.Add('选项三');
  Select1.Label_ := '请选择';
  Select1.Variant := svOutlined;
  Select1.ColorScheme := muiPrimary;
end;
```

---

## 项目结构

```
SkiaVclControls/
├── Sources/                         # 源代码
│   ├── SkiaVclControls.Types.pas        # 共享类型、枚举
│   ├── SkiaVclControls.Base.pas         # 基类
│   ├── SkiaVclControls.Button.pas       # 按钮
│   ├── SkiaVclControls.Panel.pas        # 面板
│   ├── SkiaVclControls.ButtonGroup.pas  # 按钮组
│   ├── SkiaVclControls.Radio.pas        # 单选按钮
│   ├── SkiaVclControls.RadioGroup.pas   # 单选按钮组
│   ├── SkiaVclControls.Checkbox.pas     # 复选框
│   ├── SkiaVclControls.CheckboxGroup.pas # 复选框组
│   ├── SkiaVclControls.Switch.pas       # 开关
│   ├── SkiaVclControls.SwitchGroup.pas  # 开关组
│   ├── SkiaVclControls.Select.pas       # 下拉选择器
│   ├── SkiaVclControls.Edit.pas         # 文本编辑框
│   ├── SkiaVclControls.Slider.pas       # 滑块
│   ├── SkiaVclControls.ProgressBar.pas  # 线性进度条
│   ├── SkiaVclControls.CircularProgress.pas # 环形进度条
│   ├── SkiaVclControls.Stepper.pas      # 步骤条
│   ├── SkiaVclControls.Tabs.pas         # 选项卡
│   ├── SkiaVclControls.Snackbar.pas     # 消息条
│   ├── SkiaVclControls.MUIHelper.pas    # MUI 配色 Helper
│   └── SkiaVclControls.Register.pas     # 组件注册
├── Demo/                            # 演示程序（Frame架构）
│   ├── Shared/                      # 共享单元
│   │   ├── Demo.Styles.pas          # 共享样式常量
│   │   └── Demo.MainForm.Template   # 通用主窗体模板
│   ├── Frames/                      # 可复用的演示Frame
│   │   ├── Demo.Frame.Base          # BaseFrame（IDemoFrame接口）
│   │   ├── Demo.Frame.Button        # Button演示Frame
│   │   ├── Demo.Frame.Panel         # Panel演示Frame
│   │   ├── Demo.Frame.ButtonGroup   # ButtonGroup演示Frame
│   │   ├── Demo.Frame.Radio         # Radio演示Frame
│   │   ├── Demo.Frame.Checkbox      # Checkbox演示Frame
│   │   ├── Demo.Frame.Switch        # Switch演示Frame
│   │   ├── Demo.Frame.Select        # Select演示Frame
│   │   ├── Demo.Frame.Edit          # Edit演示Frame
│   │   ├── Demo.Frame.Slider        # Slider演示Frame
│   │   ├── Demo.Frame.Progress      # Progress演示Frame
│   │   ├── Demo.Frame.Stepper       # Stepper演示Frame
│   │   ├── Demo.Frame.Tabs          # Tabs演示Frame
│   │   └── Demo.Frame.Snackbar      # Snackbar演示Frame
│   ├── Button/                      # 按钮演示
│   ├── Panel/                       # 面板演示
│   ├── ButtonGroup/                 # 按钮组演示
│   ├── Radio/                       # 单选按钮演示
│   ├── Slider/                      # 滑块演示
│   ├── Checkbox/                    # 复选框演示
│   ├── Switch/                      # 开关演示
│   ├── Select/                      # 下拉选择器演示
│   ├── Edit/                        # 文本编辑框演示
│   ├── Progress/                    # 进度条演示
│   ├── Stepper/                     # 步骤条演示
│   ├── Tabs/                        # 选项卡演示
│   ├── Snackbar/                    # 消息条演示
│   └── AdminDemo/                   # 综合展示Demo（Admin风格）
├── SkiaVclControls.dpk              # 设计时包
└── build.bat                        # 编译脚本
```

---

## Demo架构

### Frame架构设计

Demo采用**Frame架构**，实现代码复用和统一维护：

1. **共享层** (`Demo/Shared/`)
   - `Demo.Styles.pas`: Material Design 3 颜色常量、样式定义
   - `Demo.MainForm.Template`: 通用主窗体模板

2. **Frame层** (`Demo/Frames/`)
   - `Demo.Frame.Base`: 基础Frame，实现 `IDemoFrame` 接口
   - `Demo.Frame.*`: 各组件的演示Frame，可独立使用或嵌入其他容器

3. **单组件Demo** (`Demo/Button/`, `Demo/Panel/`, etc.)
   - 继承 `TDemoMainForm` 模板
   - 创建对应的 `TFrame*Demo` 并嵌入

4. **综合Demo** (`Demo/AdminDemo/`)
   - Admin风格多页面UI
   - 左侧TDSkTabs垂直导航
   - 右侧动态切换Frame
   - 复用所有组件Frame

### 运行Demo

```bash
# 编译并运行单组件Demo
cd Demo/Button
dcc32 ButtonDemo.dpr

# 编译并运行综合Demo
cd Demo/AdminDemo
dcc32 AdminDemo.dpr
```

## 截图

### TDSkButton 按钮演示
![Button Demo](screenshots/button-demo.png)

### TDSkPanel 面板演示
![Panel Demo](screenshots/panel-demo.png)

### TDSkButtonGroup 按钮组演示
![ButtonGroup Demo](screenshots/buttongroup-demo.png)

### TDSkSelect 下拉选择器演示
![Select Demo](screenshots/select-demo.png)

### TDSkSnackbar 消息条演示
![Snackbar Demo](screenshots/snackbar-demo.png)

### Admin 综合演示
![Admin Demo](screenshots/admin-demo.png)

---

## 贡献

欢迎提交 Issue 和 Pull Request！

---

## 许可证

本项目采用 [MIT](LICENSE) 许可证

---

## 致谢

- [Skia](https://skia.org/) - 强大的 2D 图形库
- [Material Design](https://m3.material.io/) - Google Material Design 3
- [Material-UI](https://mui.com/) - React UI 组件库（配色参考）
