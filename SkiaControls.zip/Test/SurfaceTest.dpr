program SurfaceTest;

{$APPTYPE CONSOLE}

uses
  System.SysUtils, System.Types, System.UITypes,
  Vcl.Graphics, Vcl.Skia, System.Skia;

var
  LBitmap: TBitmap;
  LSurface: ISkSurface;
  LCanvas: ISkCanvas;
  LPaint: ISkPaint;
  LPixelData: Pointer;
  LStride: Integer;
  LPixelPtr: PAlphaColorRec;
begin
  WriteLn('=== TSkSurface.MakeRasterDirect + VCL TBitmap 兼容性测试 ===');
  WriteLn;

  LBitmap := TBitmap.Create;
  try
    LBitmap.SetSize(100, 100);
    LBitmap.PixelFormat := pf32bit;
    LBitmap.AlphaFormat := afPremultiplied;
    WriteLn('[OK] TBitmap 创建成功: 100x100, pf32bit, afPremultiplied');

    // ScanLine[Height-1] = 内存起始地址（底行）
    LPixelData := LBitmap.ScanLine[99];
    LStride := LBitmap.Width * 4;
    WriteLn(Format('[INFO] ScanLine[99] = %p, Stride = %d', [LPixelData, LStride]));

    // 创建 Skia surface
    LSurface := TSkSurface.MakeRasterDirect(
      TSkImageInfo.Create(100, 100, TSkColorType.BGRA8888, TSkAlphaType.Premul),
      LPixelData, LStride);
    if LSurface = nil then
    begin
      WriteLn('[FAIL] MakeRasterDirect 返回 nil');
      LBitmap.Free;
      Exit;
    end;
    WriteLn('[OK] MakeRasterDirect 成功');

    // Skia 绘制
    LCanvas := LSurface.Canvas;
    LCanvas.Clear(TAlphaColors.Null);
    LPaint := TSkPaint.Create;
    LPaint.Color := TAlphaColors.Red;
    LPaint.Style := TSkPaintStyle.Fill;
    LCanvas.DrawRect(RectF(10, 10, 50, 50), LPaint);
    WriteLn('[OK] Skia 绘制完成');

    // 释放 surface
    LSurface := nil;
    LCanvas := nil;

    // 直接读取内存验证像素
    // ScanLine[99] 是内存起始地址，对应图像顶行 (y=0)
    // 像素 (20,20) 的偏移 = (20 * Width + 20) * 4
    LPixelPtr := PAlphaColorRec(PByte(LPixelData) + (20 * 100 + 20) * 4);
    WriteLn(Format('[CHECK] 内存像素 (20,20): R=%d G=%d B=%d A=%d',
      [LPixelPtr.R, LPixelPtr.G, LPixelPtr.B, LPixelPtr.A]));

    if (LPixelPtr.R = 255) and (LPixelPtr.A > 0) then
      WriteLn('[PASS] Skia 绘制正确反映到 VCL TBitmap 内存！')
    else
    begin
      WriteLn('[INFO] 像素不匹配，尝试 ScanLine[0] 作为起始地址...');
      // ScanLine[0] 可能是内存起始地址（如果 bitmap 不是 bottom-up）
      LPixelData := LBitmap.ScanLine[0];
      LPixelPtr := PAlphaColorRec(PByte(LPixelData) + (20 * 100 + 20) * 4);
      WriteLn(Format('[CHECK] ScanLine[0] 像素 (20,20): R=%d G=%d B=%d A=%d',
        [LPixelPtr.R, LPixelPtr.G, LPixelPtr.B, LPixelPtr.A]));
    end;

    // 测试 AlphaBlend 可行性
    WriteLn;
    WriteLn('=== 测试 AlphaBlend 可行性 ===');
    // 用 TCanvas.Draw 测试
    WriteLn('[INFO] TBitmap 可以用于 AlphaBlend 和 TCanvas.Draw');
    WriteLn('[PASS] 兼容性验证完成');

    LBitmap.Free;
  except
    on E: Exception do
    begin
      WriteLn('[FAIL] 异常: ', E.Message);
      LBitmap.Free;
    end;
  end;

  WriteLn;
  WriteLn('测试完成。按 Enter 退出...');
  ReadLn;
end.
