@echo off
cd /d "E:\temp\SkiaControls\Test"
"D:\Delphi 13.1\bin\dcc32.exe" -$O- -$W+ -$R+ -$Q+ --no-config -B -Q -E"." -N"." -I"D:\Delphi 13.1\Imports";"D:\Delphi 13.1\include" -U"D:\Delphi 13.1\Imports";"D:\Delphi 13.1\include";"d:\delphi 13.1\lib\Win32\release" -DDEBUG -AGenerics.Collections=System.Generics.Collections;Generics.Defaults=System.Generics.Defaults SurfaceTest.dpr
echo.
echo Exit code: %ERRORLEVEL%
pause
