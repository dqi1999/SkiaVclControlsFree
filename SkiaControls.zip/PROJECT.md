# SkiaVclControls — 基于 Delphi Skia 的 Material Design VCL 控件库

基于 Delphi 内置 Skia 支持构建的 Material Design 3 风格 VCL 控件集。

## 当前压缩上下文（2026-06-07）

- 当前主线：`TDSkSlider` 浮动值标签已解决；`TDSkLabel` 组件、AdminDemo 页面、独立 LabelDemo 已加入；AdminDemo 外壳和 `Demo\Frames` 已做统一视觉适配。
- Slider：浮动值标签使用顶层分层透明窗体 `TDSkSliderValueLabelForm` + `UpdateLayeredWindow` 绘制像素级 Alpha 内容；只在 `MouseDown`/拖动中显示，`MouseUp` 后隐藏。不要恢复 `WM_CAPTURECHANGED` 兜底逻辑，它之前会打断鼠标捕获并导致 Slider 拖不动。
- Label：组件单元必须使用 `Sources\SkiaVclControls.LabelControl.pas`，不要使用 `SkiaVclControls.Label` 或 `Demo.Frame.Label`，因为 `LABEL` 是 Delphi 保留字。当前支持纯色/线性渐变填充、描边、空心字、阴影/发光、水平/垂直对齐、AutoSize 特效边距和禁用态灰显；文本布局已改为按 Skia 真实字形边界测量/对齐，并给描边/阴影留出更保守的边距，避免运行时边缘字符显示不全。
- Demo：`Demo\Frames\Demo.Frame.LabelControl.pas/dfm` 是有效 Label Frame，已改为 DFM 设计为主；`Demo\Label\LabelDemo.dproj` 是独立 Label Demo；`Demo\AdminDemo\AdminMainForm.pas/dfm` 已接入 Label 页面。AdminDemo 左侧 `sideNav` 已按基础控件到复杂控件重新排序，并通过 `SVGIconImageList1` + `TDSkTabs.Images` 显示图标+文字导航。`Demo\Shared\Demo.Styles.pas` 新增 `ApplyAdminFrameStyle`/`ApplyDemoLabelStyle`，各普通 Frame 构造时调用以统一 Admin 风格；`FrameLabelDemo` 保留 DFM 中的渐变/描边/对齐设计属性，共享样式会跳过它，避免设计期和运行时位置不一致。其中 `TDSkRadioGroup` 标题/选项字体已统一为高对比蓝灰色和 10pt 字号。
- Label 迁移：`Demo\AdminDemo` 和 `Demo\Frames` 中旧 Delphi `TLabel` 已升级为 `TDSkLabel`，旧 `Transparent`/`ParentFont`/`StyleElements` 等 `TLabel` 专属属性已清理；`TDSkLabel.Loaded` 已补充 AutoSize 加载保护，避免 DFM 加载时提前改尺寸。
- 最近验证：`AdminDemo.dproj` 编译通过（`status=ok`、`errors=0`、`warnings=0`）；`LabelDemo.dproj` 源码编译通过（`errors=0`、`warnings=0`），但 `LabelDemo.exe` 被占用返回 `output_locked`；`ButtonDemo.dproj` 编译通过，用于验证继承 Frame 的单组件 Demo 链路。
- 调试状态：`SkiaSliderOverlay.log` 相关调试代码已清理。若编译返回 `output_locked` 且 `errors=0`，先关闭占用的 exe/IDE 后重编，不要误判为源码错误。

## 项目结构

```
E:\temp\SkiaControls\
├── Sources\                              # 组件源代码
│   ├── SkiaVclControls.Types.pas         — 共享类型、枚举
│   ├── SkiaVclControls.Base.pas          — TDSCustomSkControl 基类
│   ├── SkiaVclControls.Button.pas        — TDSkButton 实现
│   ├── SkiaVclControls.Panel.pas         — TDSkPanel 实现
│   ├── SkiaVclControls.ButtonGroup.pas   — TDSkButtonGroup 实现
│   ├── SkiaVclControls.Radio.pas         — TDSkRadio 实现
│   ├── SkiaVclControls.RadioGroup.pas    — TDSkRadioGroup 实现
│   ├── SkiaVclControls.Slider.pas        — TDSkSlider 实现
│   ├── SkiaVclControls.Checkbox.pas      — TDSkCheckbox 实现
│   ├── SkiaVclControls.CheckboxGroup.pas — TDSkCheckboxGroup 实现
│   ├── SkiaVclControls.Switch.pas        — TDSkSwitch 实现
│   ├── SkiaVclControls.SwitchGroup.pas   — TDSkSwitchGroup 实现
│   ├── SkiaVclControls.Select.pas        — TDSkSelect 实现
│   ├── SkiaVclControls.Edit.pas          — TDSkEdit 实现
│   ├── SkiaVclControls.ProgressBar.pas   — TDSkProgressBar 实现
│   ├── SkiaVclControls.CircularProgress.pas — TDSkCircularProgress 实现
│   ├── SkiaVclControls.Stepper.pas       — TDSkStepper 实现
│   ├── SkiaVclControls.Tabs.pas          — TDSkTabs 实现
│   ├── SkiaVclControls.Snackbar.pas      — TDSkSnackbar 实现
│   ├── SkiaVclControls.MUIHelper.pas     — Material-UI 配色 Helper
│   └── SkiaVclControls.Register.pas      — 组件注册单元
│
├── Demo\                                 # 演示程序（Frame架构）
│   ├── Shared\                           # 共享单元
│   │   ├── Demo.Styles.pas               — 共享样式常量和辅助函数
│   │   └── Demo.MainForm.Template.pas/dfm — 通用主窗体模板
│   │
│   ├── Frames\                           # 可复用的演示Frame
│   │   ├── Demo.Frame.Base.pas/dfm       — BaseFrame（提供IDemoFrame接口）
│   │   ├── Demo.Frame.Button.pas/dfm     — Button演示Frame
│   │   ├── Demo.Frame.Panel.pas/dfm      — Panel演示Frame
│   │   ├── Demo.Frame.ButtonGroup.pas/dfm — ButtonGroup演示Frame
│   │   ├── Demo.Frame.Radio.pas/dfm      — Radio演示Frame
│   │   ├── Demo.Frame.Checkbox.pas/dfm   — Checkbox演示Frame
│   │   ├── Demo.Frame.Switch.pas/dfm     — Switch演示Frame
│   │   ├── Demo.Frame.Select.pas/dfm     — Select演示Frame
│   │   ├── Demo.Frame.Edit.pas/dfm       — Edit演示Frame
│   │   ├── Demo.Frame.Slider.pas/dfm     — Slider演示Frame
│   │   ├── Demo.Frame.Progress.pas/dfm   — Progress演示Frame
│   │   ├── Demo.Frame.Stepper.pas/dfm    — Stepper演示Frame
│   │   ├── Demo.Frame.Tabs.pas/dfm       — Tabs演示Frame
│   │   ├── Demo.Frame.LabelControl.pas/dfm — Label演示Frame
│   │   └── Demo.Frame.Snackbar.pas/dfm   — Snackbar演示Frame
│   │
│   ├── Button\                           # 单组件Demo
│   │   ├── ButtonDemo.dpr
│   │   └── ButtonMainForm.pas/dfm
│   ├── Panel\
│   │   ├── PanelDemo.dpr
│   │   └── PanelMainForm.pas/dfm
│   ├── ButtonGroup\
│   │   ├── ButtonGroupDemo.dpr
│   │   └── ButtonGroupMainForm.pas/dfm
│   ├── Radio\
│   │   ├── RadioDemo.dpr
│   │   └── RadioMainForm.pas/dfm
│   ├── Checkbox\
│   │   ├── CheckboxDemo.dpr
│   │   └── CheckboxMainForm.pas/dfm
│   ├── Switch\
│   │   ├── SwitchDemo.dpr
│   │   └── SwitchMainForm.pas/dfm
│   ├── Select\
│   │   ├── SelectDemo.dpr
│   │   └── SelectMainForm.pas/dfm
│   ├── Edit\
│   │   ├── EditDemo.dpr
│   │   └── EditMainForm.pas/dfm
│   ├── Slider\
│   │   ├── SliderDemo.dpr
│   │   └── SliderMainForm.pas/dfm
│   ├── Progress\
│   │   ├── ProgressBarDemo.dpr
│   │   └── ProgressMainForm.pas/dfm
│   ├── Stepper\
│   │   ├── StepperDemo.dpr
│   │   └── StepperMainForm.pas/dfm
│   ├── Tabs\
│   │   ├── TabsDemo.dpr
│   │   └── TabsMainForm.pas/dfm
│   ├── Label\
│   │   ├── LabelDemo.dpr
│   │   └── LabelMainForm.pas/dfm
│   ├── Snackbar\
│   │   ├── SnackbarDemo.dpr
│   │   └── SnackbarMainForm.pas/dfm
│   │
│   └── AdminDemo\                        # 综合展示Demo（Admin风格）
│       ├── AdminDemo.dpr
│       └── AdminMainForm.pas/dfm
│
├── SkiaVclControls.dpk                   — 设计时包
└── build.bat                             — 编译脚本
```

### Demo架构说明

采用**Frame架构**设计，实现代码复用和统一维护：

1. **共享层** (`Demo/Shared/`)
   - `Demo.Styles.pas`: Material Design 3 颜色常量、样式定义、辅助函数
   - `Demo.MainForm.Template`: 通用主窗体模板，所有单组件Demo继承此模板

2. **Frame层** (`Demo/Frames/`)
   - `Demo.Frame.Base`: 基础Frame，实现 `IDemoFrame` 接口
   - `Demo.Frame.*`: 各组件的演示Frame，可独立使用或嵌入其他容器

3. **单组件Demo** (`Demo/Button/`, `Demo/Panel/`, etc.)
   - 继承 `TDemoMainForm` 模板
   - 创建对应的 `TFrame*Demo` 并嵌入

4. **综合Demo** (`Demo/AdminDemo/`)
   - Admin风格多页面UI
   - 左侧TDSkTabs垂直导航
   - 右侧动态切换Frame
   - 复用所有组件Frame

## 组件列表

### TDSCustomSkControl（基类）

所有 Skia 控件的公共基类，提供圆角、背景色、边框等基础功能。

| 属性                | 类型          | 说明                                    |
| ----------------- | ----------- | ------------------------------------- |
| `CornerRadius`    | Single      | 圆角半径，0=直角                             |
| `BackgroundColor` | TAlphaColor | 背景色 (ARGB)                            |
| `BackgroundHover` | TAlphaColor | 悬停背景色                                 |
| `BorderColor`     | TAlphaColor | 边框颜色                                  |
| `BorderWidth`     | Single      | 边框宽度，0=无边框                            |
| `Opacity`         | Byte        | 整体透明度 0\~255（继承自 TSkCustomWinControl） |

### TDSkButton

| 属性                                                                                   | 类型                 | 说明                                          |
| ------------------------------------------------------------------------------------ | ------------------ | ------------------------------------------- |
| `ButtonText`                                                                         | string             | 按钮文字                                        |
| `ButtonStyle`                                                                        | TDSkButtonStyle    | 形状：bsRectangle / bsRoundRect / bsCircle     |
| `ButtonType`                                                                         | TDSkButtonType     | 类型：btNormal / btToggle                      |
| `ButtonRound`                                                                        | Single             | 按钮圆角半径                                      |
| `Font`                                                                               | TFont              | 字体（支持 IDE 字体编辑器）                            |
| `FontColor` / `FontHover` / `FontDisabled` / `FontChecked`                           | TAlphaColor        | 四种状态字体颜色                                    |
| `ButtonColor` / `ButtonHover` / `ButtonPressed` / `ButtonDisabled` / `ButtonChecked` | TAlphaColor        | 五种状态背景色                                     |
| `HoverEffect`                                                                        | TDSkHoverEffect    | 悬停动画：heNone / heRipple / heGlow / heScaleUp |
| `MUIColorScheme`                                                                     | TDSkMUIColorScheme | MUI 颜色方案（默认 muiSchemeNone）                  |
| `MUIStyle`                                                                           | TDSkMUIStyle       | MUI 按钮样式（默认 muiStyleNone）                   |
| `Images` / `ImageIndex` / `ImageAlign`                                               | —                  | 图标支持（通过 `TChangeLink` 监听 ImageList 变化）      |
| `ImageMargin`                                                                        | Integer            | 图标与文字间距                                     |
| `Checked`                                                                            | Boolean            | 选中状态（btToggle 时切换）                          |

**MUI 主题**: 设计期直接选择 `MUIColorScheme` + `MUIStyle`，自动应用 Material Design 配色。默认 `muiSchemeNone` + `muiStyleNone` 不干预自定义颜色。

**动画**: 16ms 定时器驱动，按下缩放 0.95 倍，悬停放大 1.03 倍。

### TDSkButtonGroup

将多个 `TDSkButton` 作为一组排列，提供 Material-UI ButtonGroup 风格的相连按钮、分隔线、统一配色和选中管理。

| 属性                 | 类型                            | 说明                                                            |
| ------------------ | ----------------------------- | ------------------------------------------------------------- |
| `Orientation`      | TDSkButtonGroupOrientation    | 排列方向：bgoHorizontal / bgoVertical                              |
| `Variant`          | TDSkButtonGroupVariant        | 变体：bgvContained / bgvOutlined / bgvText                       |
| `Size`             | TDSkButtonGroupSize           | 尺寸：bgsSmall / bgsMedium / bgsLarge                            |
| `ColorScheme`      | TDSkMUIColorScheme            | MUI 配色：Primary / Secondary / Error / Warning / Info / Success |
| `DisableElevation` | Boolean                       | 填充样式下禁用加深的悬停效果                                                |
| `FullWidth`        | Boolean                       | 子按钮平分容器宽度或高度                                                  |
| `Exclusive`        | Boolean                       | 是否只允许一个按钮被选中                                                  |
| `AllowNone`        | Boolean                       | 选中项再次点击时是否允许清空选择                                              |
| `ItemIndex`        | Integer                       | 当前选中按钮索引，-1 表示未选中                                             |
| `Spacing`          | Single                        | 子按钮间距，默认 0 为相连按钮                                              |
| `OnItemClick`      | TDSkButtonGroupItemClickEvent | 子按钮点击和选中变化事件                                                  |

**使用方式**: 将 `TDSkButton` 放入 `TDSkButtonGroup` 中，按钮组会统一设置子按钮圆角、颜色、尺寸和选中状态。

### TDSkPanel

| 属性                | 类型                  | 说明                       |
| ----------------- | ------------------- | ------------------------ |
| `Caption`         | string              | 标题文字                     |
| `CaptionPosition` | TDSkCaptionPosition | 九宫格位置                    |
| `CaptionFont`     | TFont               | 标题字体                     |
| `CaptionMargin`   | Single              | 标题边距                     |
| `ChildPadding`    | Single              | 子控件内边距                   |
| `PanelStyle`      | TDSkPanelStyle      | MD3 容器样式（默认 psStyleNone） |
| `BackgroundHover` | TAlphaColor         | 悬停背景色                    |
| `HoverEnabled`    | Boolean             | 是否启用悬停背景切换（默认 False） |

**PanelStyle 预设**:

| 值                    | 背景色     | 边框    | 圆角 | 说明    |
| -------------------- | ------- | ----- | -- | ----- |
| psElevated           | #FFFFFF | 0.5px | 12 | 浮起卡片  |
| psFilled             | #F5F5F5 | 无     | 12 | 填充样式  |
| psOutlined           | #FFFFFF | 1px   | 12 | 轮廓样式  |
| psSurface            | #FAFAFA | 无     | 12 | 最低层级  |
| psPrimaryContainer   | #E3F2FD | 无     | 12 | 主色浅底  |
| psSecondaryContainer | #F3E5F5 | 无     | 12 | 次色浅底  |
| psErrorContainer     | #FFEBEE | 无     | 12 | 错误色浅底 |
| psStyleNone          | —       | —     | —  | 不使用预设 |

### TDSkRadio

MUI 风格的单选按钮组件，无边框、透明背景，提供选中/未选中状态切换。

| 属性                | 类型                    | 说明                         |
| ----------------- | --------------------- | -------------------------- |
| `Checked`         | Boolean               | 选中状态                       |
| `Caption`         | string                | 标签文本                       |
| `LabelPlacement`  | TDSkRadioLabelPlacement | 标签放置（上、下、左、右）            |
| `ColorScheme`     | TDSkMUIColorScheme    | MUI 颜色方案                   |
| `RadioSize`       | Single                | 单选按钮大小                     |
| `Font`            | TFont                 | 标签字体                       |
| `Error`           | Boolean               | 错误状态                       |
| `OnCheckChanged`  | TNotifyEvent          | 选中状态变化事件                  |

**MUI 风格特点**:
- 未选中状态：细线空心圆（1.5px 边框）
- 选中状态：实心小圆 + 外圈（外圈颜色 50% 透明度）
- 悬停效果：外圈颜色加深 15%
- 背景透明：无边框、无背景色
- 禁用状态：灰色显示

**使用方式**: 单独使用或放入 `TDSkRadioGroup` 中管理。

### TDSkRadioGroup

MUI 风格的单选按钮组容器，自行绘制所有单选按钮，不创建子组件。支持标题显示。

| 属性                | 类型                         | 说明                         |
| ----------------- | -------------------------- | -------------------------- |
| `Orientation`     | TDSkRadioGroupOrientation  | 布局方向（垂直/水平）               |
| `ItemIndex`       | Integer                    | 当前选中项索引                    |
| `Items`           | TStrings                   | 选项文本列表                     |
| `Caption`         | string                     | 标题文字（显示在第一行）              |
| `CaptionFont`     | TFont                      | 标题字体                       |
| `CaptionMargin`   | Single                     | 标题与选项的间距                   |
| `RadioSize`       | Single                     | Radio 按钮大小（默认 20）          |
| `ItemFont`        | TFont                      | 选项文字字体                     |
| `ColorScheme`     | TDSkMUIColorScheme         | 统一颜色方案                     |
| `LabelPlacement`  | TDSkRadioLabelPlacement    | 统一标签放置                     |
| `Exclusive`       | Boolean                    | 是否只能选一个（默认 True）          |
| `OnItemClick`     | TDSkRadioGroupItemClickEvent | 选中项变化事件                  |

**使用方式**: 设置 `Items` 属性自动创建单选按钮，通过 `ItemIndex` 获取或设置选中项。设置 `Caption` 显示标题文字。设置 `RadioSize` 调整按钮大小，设置 `ItemFont` 调整选项字体。

### TDSkSlider

MUI 风格的滑块组件，支持连续滑块、间续滑块、范围滑块和垂直滑块。

| 属性                | 类型                          | 说明                                    |
| ----------------- | --------------------------- | ------------------------------------- |
| `Min`             | Single                      | 最小值，默认 0                             |
| `Max`             | Single                      | 最大值，默认 100                           |
| `Value`           | Single                      | 当前值（单滑块模式）                          |
| `ValueLow`        | Single                      | 范围滑块的低值                              |
| `ValueHigh`       | Single                      | 范围滑块的高值                              |
| `Step`            | Single                      | 步进值，0 为连续滑块                          |
| `Orientation`     | TDSkSliderOrientation       | 方向：sloHorizontal / sloVertical        |
| `ColorScheme`     | TDSkMUIColorScheme          | MUI 颜色方案（默认 muiPrimary）               |
| `ShowValueLabel`  | TDSkSliderValueLabelDisplay | 值标签显示：svldAuto / svldOn / svldOff      |
| `ShowMarks`       | Boolean                     | 是否显示标记（默认 False）                     |
| `TrackVisible`    | TDSkSliderTrack             | 轨道显示：stNormal / stFalse / stInverted   |
| `ThumbSize`       | Single                      | 滑块大小（默认 10）                           |
| `TrackHeight`     | Single                      | 轨道高度（默认 4）                            |
| `Range`           | Boolean                     | 是否为范围滑块（默认 False）                    |
| `Font`            | TFont                       | 字体                                     |
| `ValueLabelFormat`| string                      | 值标签格式化字符串（默认 '%.0f'）                |
| `OnChange`        | TDSkSliderChangeEvent       | 值变化事件                                |
| `OnRangeChange`   | TDSkSliderRangeChangeEvent  | 范围值变化事件                              |

**MUI 风格特点**:
- 轨道：灰色背景轨道 + 彩色活动轨道
- 滑块：圆形滑块，悬停时放大效果
- 值标签：悬停/拖动时显示彩色背景的值标签
- 标记：可添加自定义标记和标签
- 颜色方案：支持 Primary / Secondary / Error / Warning / Info / Success
- 键盘支持：方向键、Home、End 键

**使用方式**: 设置 `Min` 和 `Max` 定义范围，通过 `Value` 获取或设置当前值。设置 `Step` 启用间续滑块。设置 `Range := True` 启用范围滑块。使用 `AddMark` 方法添加自定义标记。

### TDSkCheckbox

MUI 风格的复选框组件，支持三态（未选中、选中、不确定）。无边框、透明背景，可单独使用或放入 `TDSkCheckboxGroup` 中管理。

| 属性                | 类型                    | 说明                         |
| ----------------- | --------------------- | -------------------------- |
| `Checked`         | Boolean               | 选中状态                       |
| `Indeterminate`   | Boolean               | 不确定状态（第三态）                 |
| `Caption`         | string                | 标签文本                       |
| `LabelPlacement`  | TDSkRadioLabelPlacement | 标签放置（上、下、左、右）            |
| `ColorScheme`     | TDSkMUIColorScheme    | MUI 颜色方案                   |
| `CheckboxSize`    | Single                | Checkbox 大小（默认 20）         |
| `Font`            | TFont                 | 标签字体                       |
| `Error`           | Boolean               | 错误状态（红色）                   |
| `OnCheckChanged`  | TNotifyEvent          | 选中状态变化事件                  |

**MUI 风格特点**:
- 未选中状态：圆角矩形边框（2px，灰色）
- 选中状态：实心圆角矩形（主题色）+ 白色勾选图标
- 不确定状态：实心圆角矩形（主题色）+ 白色横线
- 悬停效果：无额外效果（保持简洁）
- 背景透明：无边框、无背景色
- 禁用状态：灰色显示
- 圆角半径：3px

**使用方式**: 通过 `Checked` 和 `Indeterminate` 属性控制状态。设置 `Toggle` 方法切换状态。不确定状态点击后会变为选中状态。

### TDSkCheckboxGroup

MUI 风格的复选框组容器，自行绘制所有复选框，不创建子组件。默认多选模式，可设置为单选模式。

| 属性                | 类型                         | 说明                         |
| ----------------- | -------------------------- | -------------------------- |
| `Orientation`     | TDSkRadioGroupOrientation  | 布局方向（垂直/水平）               |
| `Items`           | TStrings                   | 选项文本列表                     |
| `CheckedItems`    | TList\<Integer\>           | 选中项索引集合                    |
| `Caption`         | string                     | 标题文字（显示在第一行）              |
| `CaptionFont`     | TFont                      | 标题字体                       |
| `CaptionMargin`   | Single                     | 标题与选项的间距                   |
| `CheckboxSize`    | Single                     | Checkbox 大小（默认 20）         |
| `ItemFont`        | TFont                      | 选项文字字体                     |
| `ColorScheme`     | TDSkMUIColorScheme         | 统一颜色方案                     |
| `LabelPlacement`  | TDSkRadioLabelPlacement    | 统一标签放置                     |
| `Exclusive`       | Boolean                    | 是否只能选一个（默认 False，多选）      |
| `AllowNone`       | Boolean                    | 单选模式下是否允许取消选中（默认 True）   |
| `OnItemClick`     | TDSkCheckboxGroupItemClickEvent | 选中项变化事件                  |

**使用方式**: 设置 `Items` 属性自动创建复选框，通过 `CheckedItems` 获取或设置选中项。设置 `Exclusive := True` 切换为单选模式。设置 `Caption` 显示标题文字。使用 `IsItemChecked(Index)` 查询选中状态，`SetItemChecked(Index, Value)` 设置选中状态，`ClearCheckedItems` 清除所有选中。

### TDSkSwitch

MUI 风格的开关组件，轨道 + 滑块的滑动开关，支持 Small/Medium 两种尺寸。无边框、透明背景，可单独使用或放入 `TDSkSwitchGroup` 中管理。

| 属性                | 类型                    | 说明                         |
| ----------------- | --------------------- | -------------------------- |
| `Checked`         | Boolean               | 开关状态                       |
| `Caption`         | string                | 标签文本                       |
| `LabelPlacement`  | TDSkRadioLabelPlacement | 标签放置（上、下、左、右）            |
| `ColorScheme`     | TDSkMUIColorScheme    | MUI 颜色方案                   |
| `Size`            | TDSkSwitchSize        | 尺寸：sssSmall / sssMedium     |
| `Font`            | TFont                 | 标签字体                       |
| `OnCheckChanged`  | TNotifyEvent          | 状态变化事件                     |

**MUI 风格特点**:
- 关闭状态：灰色轨道（`#E0E0E0`），白色滑块在左侧
- 开启状态：主题色轨道，白色滑块在右侧
- 禁用状态：灰色轨道，50% 透明度
- 滑块带有轻微阴影效果

**尺寸规格**:

| 尺寸 | 轨道宽 | 轨道高 | 滑块直径 |
|------|--------|--------|----------|
| Small | 28 | 16 | 12 |
| Medium | 36 | 20 | 18 |

**使用方式**: 通过 `Checked` 属性控制开关状态。设置 `Toggle` 方法切换状态。

### TDSkSwitchGroup

MUI 风格的开关组容器，自行绘制所有开关，不创建子组件。默认多选模式，可设置为单选模式。

| 属性                | 类型                         | 说明                         |
| ----------------- | -------------------------- | -------------------------- |
| `Orientation`     | TDSkRadioGroupOrientation  | 布局方向（垂直/水平）               |
| `Items`           | TStrings                   | 选项文本列表                     |
| `CheckedItems`    | TList\<Integer\>           | 选中项索引集合                    |
| `Caption`         | string                     | 标题文字（显示在第一行）              |
| `CaptionFont`     | TFont                      | 标题字体                       |
| `CaptionMargin`   | Single                     | 标题与选项的间距                   |
| `ItemFont`        | TFont                      | 选项文字字体                     |
| `ColorScheme`     | TDSkMUIColorScheme         | 统一颜色方案                     |
| `LabelPlacement`  | TDSkRadioLabelPlacement    | 统一标签放置                     |
| `Size`            | TDSkSwitchSize             | 统一尺寸（默认 sssMedium）          |
| `Exclusive`       | Boolean                    | 是否只能选一个（默认 False，多选）      |
| `AllowNone`       | Boolean                    | 单选模式下是否允许取消选中（默认 True）   |
| `OnItemClick`     | TDSkSwitchGroupItemClickEvent | 选中项变化事件                  |

**使用方式**: 设置 `Items` 属性自动创建开关，通过 `CheckedItems` 获取或设置选中项。设置 `Exclusive := True` 切换为单选模式。设置 `Size` 统一调整尺寸。

### TDSkSelect

MUI 风格的下拉选择器组件，支持 Outlined / Filled / Underline 三种变体、浮动标签、下拉列表、清除按钮和错误状态。

| 属性                | 类型                          | 说明                                    |
| ----------------- | --------------------------- | ------------------------------------- |
| `Items`           | TStrings                    | 选项列表                                |
| `ItemIndex`       | Integer                     | 当前选中项索引，-1 表示未选中                   |
| `Text`            | string                      | 显示文本（覆盖选中项文本）                      |
| `Label_`          | string                      | 浮动标签文字                              |
| `Placeholder`     | string                      | 占位提示文字                              |
| `HelperText`      | string                      | 底部帮助文字                              |
| `Variant`         | TDSkSelectVariant           | 变体：svOutlined / svFilled / svUnderline |
| `ColorScheme`     | TDSkMUIColorScheme          | MUI 颜色方案（默认 muiPrimary）               |
| `LabelPlacement`  | TDSkSelectLabelPlacement    | 标签行为：slpFloat / slpShrink             |
| `Font`            | TFont                       | 输入文字字体（默认 #495057）                   |
| `LabelFont`       | TFont                       | 标签字体（默认 12pt）                        |
| `MaxDropCount`    | Integer                     | 下拉最大可见行数（默认 8）                      |
| `ReadOnly`        | Boolean                     | 只读状态                                |
| `Error`           | Boolean                     | 错误状态（红色边框）                          |
| `ErrorText`       | string                      | 错误提示文字                              |
| `Clearable`       | Boolean                     | 显示清除按钮（默认 False）                    |
| `Size`            | TDSkSelectSize              | 尺寸：ssMedium（62px）/ ssSmall（46px）     |
| `DroppedDown`     | Boolean                     | 下拉状态（只读）                            |
| `OnItemClick`     | TDSkSelectItemClickEvent    | 选中项变化事件                             |
| `OnDropDown`      | TNotifyEvent                | 下拉事件                                |
| `OnCloseUp`       | TNotifyEvent                | 关闭事件                                |

**MUI 风格特点**:
- Outlined 变体：带边框，白底，标签上浮时在边框处留缺口，标签中心对齐边框线
- Filled 变体：灰色底，只有底部边框
- Underline 变体：透明背景，只有底部横线（标准样式）
- 浮动标签（slpFloat）：无值时标签居中显示在框内充当占位符（不显示额外 Placeholder），有值/焦点时标签上浮到框线上
- 固定标签（slpShrink）：标签始终显示在框线上方
- 下拉列表：独立弹出窗口，支持滚动、悬停高亮、选中高亮（主题色勾选图标）
- 清除按钮：点击 × 清除选中
- 错误状态：红色边框 + 错误提示文字
- 键盘支持：Space/Down 打开下拉，Escape 关闭，↑↓ 导航，Enter 选中

**使用方式**: 设置 `Items` 属性添加选项，通过 `ItemIndex` 获取或设置选中项。设置 `Label_` 显示浮动标签。设置 `Placeholder` 显示占位提示。设置 `Clearable := True` 显示清除按钮。设置 `Error := True` 显示错误状态。设置 `Size := ssSmall` 使用紧凑模式。

### TDSkEdit

MUI 风格的文本编辑框组件，支持 Outlined / Filled / Underline 三种变体、浮动标签、文本输入、选区操作、清除按钮和错误状态。与 `TDSkSelect` 显示风格一致。

| 属性                | 类型                          | 说明                                    |
| ----------------- | --------------------------- | ------------------------------------- |
| `Text`            | string                      | 当前文本内容                              |
| `Label_`          | string                      | 浮动标签文字                              |
| `Placeholder`     | string                      | 占位提示文字                              |
| `HelperText`      | string                      | 底部帮助文字                              |
| `ErrorText`       | string                      | 错误提示文字                              |
| `Error`           | Boolean                     | 错误状态（红色边框）                          |
| `Clearable`       | Boolean                     | 显示清除按钮（默认 False）                    |
| `ReadOnly`        | Boolean                     | 只读状态                                |
| `MaxLength`       | Integer                     | 最大字符数，0=不限制（默认 0）                   |
| `PasswordChar`    | Char                        | 密码掩码字符，#0=不使用（默认 #0）               |
| `Variant`         | TDSkEditVariant             | 变体：evOutlined / evFilled / evUnderline |
| `ColorScheme`     | TDSkMUIColorScheme          | MUI 颜色方案（默认 muiPrimary）               |
| `LabelPlacement`  | TDSkEditLabelPlacement      | 标签行为：elpFloat / elpShrink             |
| `Font`            | TFont                       | 输入文字字体（默认 #495057）                   |
| `LabelFont`       | TFont                       | 标签字体（默认 12pt）                        |
| `Size`            | TDSkEditSize                | 尺寸：esMedium（62px）/ esSmall（46px）     |
| `OnChange`        | TDSkEditChangeEvent         | 文本变化事件                              |
| `SelStart`        | Integer                     | 选区起始位置                              |
| `SelLength`       | Integer                     | 选区长度                                |
| `SelText`         | string                      | 选中文本（只读）                            |

**MUI 风格特点**:
- Outlined 变体：带边框，白底，标签上浮时在边框处留缺口，标签中心对齐边框线
- Filled 变体：灰色底，只有底部边框
- Underline 变体：透明背景，只有底部横线（标准样式）
- 浮动标签（elpFloat）：无值时标签居中显示在框内充当占位符（不显示额外 Placeholder），有值/焦点时标签上浮到框线上
- 固定标签（elpShrink）：标签始终显示在框线上方
- 文本输入：支持光标闪烁、文本选区、鼠标拖选、双击全选
- 清除按钮：点击 × 清除文本
- 错误状态：红色边框 + 错误提示文字
- 键盘支持：方向键移动光标、Home/End、Shift+方向键选区、Ctrl+A/C/X/V
- 密码模式：PasswordChar 设置掩码字符
- 最大长度：MaxLength 限制输入字符数

**使用方式**: 设置 `Text` 属性获取或设置文本。设置 `Label_` 显示浮动标签。设置 `Placeholder` 显示占位提示。设置 `Clearable := True` 显示清除按钮。设置 `Error := True` 显示错误状态。设置 `Size := esSmall` 使用紧凑模式。设置 `PasswordChar := '*'` 启用密码模式。

### TDSkProgressBar

MUI 风格的线性进度条组件，支持定量、不定量和缓冲三种变体。参考 Material-UI LinearProgress 组件。

| 属性                | 类型                          | 说明                                    |
| ----------------- | --------------------------- | ------------------------------------- |
| `Min`             | Single                      | 最小值，默认 0                             |
| `Max`             | Single                      | 最大值，默认 100                           |
| `Value`           | Single                      | 当前进度值                                |
| `ValueBuffer`     | Single                      | 缓冲值（仅 Buffer 变体有效）                   |
| `Variant`         | TDSkProgressBarVariant      | 变体：pbvDeterminate / pbvIndeterminate / pbvBuffer |
| `Orientation`     | TDSkProgressBarOrientation  | 方向：pboHorizontal / pboVertical        |
| `ColorScheme`     | TDSkMUIColorScheme          | MUI 颜色方案（默认 muiPrimary）               |
| `BarColor`        | TAlphaColor                 | 自定义进度条颜色（覆盖 ColorScheme）             |
| `TrackColor`      | TAlphaColor                 | 自定义轨道背景色                             |
| `TrackHeight`     | Single                      | 轨道高度（默认 4）                            |
| `Rounded`         | Boolean                     | 圆角末端（默认 True）                         |
| `ShowLabel`       | Boolean                     | 显示百分比标签（默认 False）                     |
| `Font`            | TFont                       | 标签字体                                  |
| `ValueLabelFormat`| string                      | 标签格式化字符串（默认 '%.0f%%'）                |
| `OnChange`        | TNotifyEvent                | 值变化事件                                |

**MUI 风格特点**:
- 轨道：浅灰色背景轨道（#E0E0E0）
- 进度条：主题色填充
- 不定量模式：两根条形循环流动动画（~60fps）
- 缓冲模式：半透明缓冲条 + 实心进度条
- 圆角末端：轨道和进度条均有圆角（Rounded=True 时）
- 垂直方向：进度从底部向上增长
- 标签：百分比文字居中显示

**使用方式**: 设置 `Min` 和 `Max` 定义范围，通过 `Value` 获取或设置当前进度。设置 `Variant := pbvIndeterminate` 启用不定量动画。设置 `Variant := pbvBuffer` 启用缓冲模式。设置 `ShowLabel := True` 显示百分比标签。

### TDSkCircularProgress

MUI 风格的环形进度条组件，支持定量和不定量两种变体。参考 Material-UI CircularProgress 组件。

| 属性                | 类型                              | 说明                                    |
| ----------------- | ------------------------------- | ------------------------------------- |
| `Min`             | Single                          | 最小值，默认 0                             |
| `Max`             | Single                          | 最大值，默认 100                           |
| `Value`           | Single                          | 当前进度值                                |
| `Variant`         | TDSkCircularProgressVariant     | 变体：cpvDeterminate / cpvIndeterminate  |
| `ColorScheme`     | TDSkMUIColorScheme              | MUI 颜色方案（默认 muiPrimary）               |
| `ProgressColor`   | TAlphaColor                     | 自定义进度颜色（覆盖 ColorScheme）              |
| `TrackColor`      | TAlphaColor                     | 自定义轨道背景色                             |
| `CircleSize`      | Single                          | 圆环直径（默认 40）                           |
| `Thickness`       | Single                          | 线条粗细（默认 3.6）                          |
| `ShowLabel`       | Boolean                         | 显示百分比标签（默认 False）                     |
| `Font`            | TFont                           | 标签字体                                  |
| `ValueLabelFormat`| string                          | 标签格式化字符串（默认 '%.0f%%'）                |
| `OnChange`        | TNotifyEvent                    | 值变化事件                                |

**MUI 风格特点**:
- 轨道：浅灰色背景圆环（#E0E0E0）
- 进度弧：主题色弧线，从顶部（-90度）开始顺时针绘制
- 不定量模式：旋转弧线动画，弧长从小到大再到小循环变化（~60fps）
- 圆角端点：弧线两端使用圆角（Round Cap）
- 标签：百分比文字居中显示在圆环内

**使用方式**: 设置 `Min` 和 `Max` 定义范围，通过 `Value` 获取或设置当前进度。设置 `Variant := cpvIndeterminate` 启用不定量旋转动画。设置 `CircleSize` 调整圆环大小，设置 `Thickness` 调整线条粗细。设置 `ShowLabel := True` 在圆环内显示百分比标签。

### TDSkStepper

MUI 风格的步骤条组件，参考 Material-UI Stepper 组件。支持水平/垂直方向、线性/非线性模式、步骤状态管理和连接线显示。

| 属性                | 类型                          | 说明                                    |
| ----------------- | --------------------------- | ------------------------------------- |
| `Steps`           | TDSkStepItems               | 步骤项集合                               |
| `ActiveStep`      | Integer                     | 当前活动步骤索引（默认 0）                     |
| `Orientation`     | TDSkStepperOrientation      | 方向：stoHorizontal / stoVertical        |
| `Variant`         | TDSkStepperVariant          | 变体：svLinear / svNonLinear             |
| `LabelLayout`     | TDSkStepperLabelLayout      | 标签布局：sllStandard / sllAlternative    |
| `ColorScheme`     | TDSkMUIColorScheme          | MUI 颜色方案（默认 muiPrimary）               |
| `StepSize`        | Single                      | 步骤圆圈大小（默认 32）                       |
| `StepSpacing`     | Single                      | 步骤间距（默认 60，最小 40）                   |
| `AutoFit`         | Boolean                     | 自动调节间距（默认 False）                     |
| `ConnectorThickness` | Single                   | 连接线粗细（默认 2）                          |
| `StepFont`        | TFont                       | 步骤数字字体                              |
| `LabelFont`       | TFont                       | 步骤标签字体                              |
| `DescriptionFont` | TFont                       | 步骤描述字体                              |
| `OnStepClick`     | TDSkStepperStepClickEvent   | 步骤点击事件                              |

**TDSkStepItem 属性**:

| 属性          | 类型           | 说明                                    |
| ------------- | -------------- | ------------------------------------- |
| `Caption`     | string         | 步骤标签文字                              |
| `Description` | string         | 步骤描述文字                              |
| `Status`      | TDSkStepStatus | 步骤状态：ssPending / ssActive / ssCompleted / ssError |
| `Optional`    | Boolean        | 是否可选步骤（默认 False）                    |

**MUI 风格特点**:
- 待处理状态：灰色空心圆圈 + 灰色数字
- 活动状态：主题色实心圆圈 + 白色数字
- 完成状态：主题色实心圆圈 + 白色勾
- 错误状态：红色实心圆圈 + 白色叉
- 连接线：已完成步骤之间显示主题色连接线，否则显示灰色连接线
- 标签布局：标准布局（标签在右侧）或备选布局（标签在图标下方，仅水平有效）

**自适应间距**:
- `AutoFit = False`：使用 `StepSpacing` 属性指定的固定间距
- `AutoFit = True`：根据控件宽度和步骤数量自动计算间距
- 自动计算公式：`间距 = (控件宽度 - 首尾边距 - 步骤图标总宽度 - 80) / (步骤数量 - 1)`
- 最小间距限制为 40 像素
- 为最后一个步骤预留 80 像素文字显示空间

**使用方式**: 通过 `Steps` 属性添加步骤项，设置 `ActiveStep` 控制当前步骤。使用 `NextStep` / `PrevStep` 方法前进后退。设置 `SetStepStatus` 方法手动设置步骤状态。设置 `Variant := svNonLinear` 启用非线性模式（可任意跳转）。设置 `AutoFit := True` 启用自适应间距。

### TDSkTabs

MUI 风格的选项卡组件，参考 Material-UI Tabs 组件。支持标准、全宽和居中三种变体，水平/垂直方向，主题色指示器和悬停效果。

| 属性                | 类型                          | 说明                                    |
| ----------------- | --------------------------- | ------------------------------------- |
| `Items`           | TStrings                    | 标签文本列表                              |
| `ItemIndex`       | Integer                     | 当前选中项索引，-1 表示未选中                   |
| `Variant`         | TDSkTabsVariant             | 外观样式：tvStandard / tvBottomNav |
| `Alignment`       | TDSkTabsAlignment           | 位置：taLeft / taCenter / taFullWidth |
| `Orientation`     | TDSkTabsOrientation         | 方向：toHorizontal / toVertical        |
| `IndicatorColor`  | TDSkTabIndicatorColor       | 指示器颜色：ticPrimary / ticSecondary    |
| `TextColor`       | TDSkTabTextColor            | 文本颜色：ttcPrimary / ttcSecondary     |
| `ColorScheme`     | TDSkMUIColorScheme          | MUI 颜色方案（默认 muiPrimary）               |
| `TabFont`         | TFont                       | 标签字体                                |
| `TabHeight`       | Single                      | 标签高度（默认 48）                         |
| `IndicatorHeight` | Single                      | 指示器高度（默认 3）                         |
| `TabPadding`      | Single                      | 标签内边距（默认 16）                         |
| `OnItemClick`     | TDSkTabsItemClickEvent      | 标签点击事件                              |

**MUI 风格特点**:
- 标签：文本标签，支持悬停效果（8% 透明度主题色背景）
- 指示器：底部（水平）或右侧（垂直）的主题色横条，带圆角
- 选中状态：标签文字使用主题色，指示器显示
- 未选中状态：标签文字使用灰色
- 悬停效果：标签背景显示 8% 透明度的主题色
- 颜色方案：支持 Primary / Secondary / Error / Warning / Info / Success

**外观样式（Variant）**:
- `tvStandard`：标准样式 - 纯文字+底部指示条，选中项文字变色
- `tvBottomNav`：底部导航样式 - 图标+文字+背景色+选中指示条（白色文字）

**位置对齐（Alignment）**:
- `taLeft`：靠左排列
- `taCenter`：居中排列
- `taFullWidth`：全宽排列（标签平分容器宽度）

**使用方式**: 设置 `Items` 属性添加标签，通过 `ItemIndex` 获取或设置选中项。设置 `Variant` 控制外观样式。设置 `Alignment` 控制位置对齐。设置 `ColorScheme` 统一颜色方案。设置 `TabFont` 调整标签字体。设置 `Images` 关联图标列表，Items 支持 "文字:图标索引" 格式。

### TDSkSnackbar

MUI 风格的消息条组件，从屏幕底部滑入的简短消息，支持自动隐藏、操作按钮和堆叠显示。参考 Material-UI Snackbar 组件。

| 属性                | 类型                          | 说明                                    |
| ----------------- | --------------------------- | ------------------------------------- |
| `Message`         | string                      | 消息文本                                |
| `Severity`        | TDSkSnackbarSeverity        | 严重程度：snkSuccess / snkError / snkWarning / snkInfo / snkNone |
| `Variant`         | TDSkSnackbarVariant         | 变体：snvStandard / snvFilled / snvOutlined |
| `Position`        | TDSkSnackbarPosition        | 位置：spTopLeft / spTopCenter / spTopRight / spBottomLeft / spBottomCenter / spBottomRight |
| `AutoHideDuration`| Integer                     | 自动隐藏时间（毫秒），0=不自动隐藏（默认 4000）   |
| `ActionText`      | string                      | 操作按钮文本（如 "UNDO"）                   |
| `ShowCloseButton` | Boolean                     | 是否显示关闭按钮（默认 False）                  |
| `Font`            | TFont                       | 消息字体                                |
| `ActionFont`      | TFont                       | 操作按钮字体                              |
| `OnAction`        | TDSkSnackbarActionEvent     | 操作按钮点击事件                            |
| `OnClose`         | TNotifyEvent                | 关闭事件                                |
| `OnShow`          | TNotifyEvent                | 显示事件                                |

**MUI 风格特点**:
- 从屏幕底部滑入显示，支持淡入/滑出动画
- 严重程度自动应用 MUI 配色（Success=绿, Error=红, Warning=橙, Info=蓝, None=深灰）
- 左侧图标：Success=圆圈+勾，Error=圆圈+X，Warning=三角形+感叹号，Info=圆圈+i
- 图标使用 Skia 矢量绘制，支持所有严重程度类型
- 支持堆叠显示，多个 Snackbar 垂直排列
- 操作按钮：可选的文本操作按钮（如 UNDO）
- 关闭按钮：可选的 × 关闭按钮
- 自动隐藏：定时器驱动，可配置持续时间
- 圆角半径：8px，更符合 MUI 设计规范
- **多行文本支持**：文字过长时自动换行（最多 2 行），超出部分截断并显示 "..."
- **自动高度调整**：根据文本行数自动调整 Snackbar 高度
- **操作按钮定位**：多行文本时操作按钮固定在底部右侧

**配色方案**:

| Severity | Background | Light | Dark |
|----------|------------|-------|------|
| snkSuccess | #43A047 | #66BB6A | #2E7D32 |
| snkError | #D32F2F | #EF5350 | #C62828 |
| snkWarning | #FF9800 | #FFB74D | #F57C00 |
| snkInfo | #2196F3 | #64B5F6 | #1565C0 |
| snkNone | #323232 | #616161 | #212121 |

**使用方式**: 通过 `Show` 方法显示 Snackbar，通过 `Hide` 方法隐藏。使用 `ShowSnackbar` 类方法快速显示临时消息。设置 `AutoHideDuration` 控制自动隐藏时间，设置为 0 则需手动关闭。设置 `ActionText` 添加操作按钮，通过 `OnAction` 事件处理按钮点击。设置 `ShowCloseButton := True` 显示关闭按钮。

**快速显示**:
```pascal
TDSkSnackbar.ShowSnackbar(Self, 'Operation completed!', snkSuccess);
TDSkSnackbar.ShowSnackbar(Self, 'Item deleted', snkNone, spBottomCenter, 6000, 'UNDO');
```

## Tabs 状态（2026-06-05）

- `TDSkTabs` 已实现并编译通过。
- 支持功能：标准/容器/底部导航外观样式、靠左/居中/全宽位置对齐、水平/垂直方向、MUI 配色方案、指示器颜色、悬停效果。
- 属性设置器统一使用 `RequestRedraw` → `Redraw` 触发重绘。
- 设计期样式变更现已实时更新（统一使用 `Redraw` 替代 `Invalidate`）。
- 修复了垂直排列只能看到一个tab的问题 - 重新实现了 `GetTabRect` 函数，使其在垂直模式下正确计算标签位置。
- 修复了居中样式无效的问题 - 正确计算所有标签总宽度后居中排列。
- 新增 `tvBottomNav` 底部导航样式 - 图标+文字+背景色+选中指示条（白色文字）。
- 新增 `Images` 属性支持图标显示，Items 支持 "文字:图标索引" 格式。
- 新增 `Alignment` 属性控制位置对齐（靠左/居中/全宽），与 `Variant` 外观样式独立。
- 更新了 Tabs demo，支持所有变体样式和位置对齐切换。

## Snackbar 状态（2026-06-06）

- `TDSkSnackbar` 已实现并编译通过。
- 支持功能：6个位置锚点、3种严重程度配色、3种变体样式、自动隐藏、操作按钮、关闭按钮、堆叠显示。
- 动画效果：从底部滑入/滑出，使用 16ms 定时器驱动。
- 堆叠管理：使用全局 SnackbarList 管理多个 Snackbar 实例，新消息显示在底部，旧消息向上移动。
- 新增左侧图标：Success=圆圈+勾，Error=圆圈+X，Warning=三角形+感叹号，Info=圆圈+i。
- 图标使用 Skia 矢量绘制，支持所有严重程度类型。
- 圆角半径调整为 8px，更符合 MUI 设计规范。
- **新增多行文本支持**：
  - 文字过长时自动换行（最多 2 行），超出部分截断并显示 "..."
  - 根据文本行数自动调整 Snackbar 高度
  - 操作按钮在多行文本时固定在底部右侧
  - 最大宽度限制为 560px（匹配 MUI 规范）
- **Snackbar Demo 已改为 DFM 设计为主**：
  - 所有按钮、选项组、面板和 Snackbar 实例在 DFM 中静态定义
  - PAS 文件简化为事件处理代码，不再动态创建组件
  - 新增 Position/Variant/Duration 三个选项组控制 Snackbar 行为
  - 新增 Multi-Line 和 Custom Message 演示按钮
  - 编译通过验证

## Button 优化（2026-06-06）

### 绘制效率优化
- **对象缓存**：新增 `FFillPaint`、`FStrokePaint`、`FRoundRect`、`FPathBuilder` 成员变量缓存绘制对象
- **文字绘制独立画笔**：`DrawButtonText` 使用独立的 `LTextPaint`，避免状态污染

### Ripple 效果重写（MUI 风格）
- **从点击位置扩散**：记录 `FRippleOrigin`（鼠标点击位置），而非从中心扩散
- **快速扩散**：使用 ease-out 缓动函数，约 0.35 秒完成
- **透明度渐变**：从 0.35 渐变到 0

### 设计模式修复
- **SetWindowRgn 优化**：第三个参数改为 `False`，避免触发不必要的重绘循环
- **PaintDesignTime 修复**：使用 `SaveDC`/`RestoreDC` 确保裁剪区域正确清除
- **FLoading 标志修复**：构造函数末尾设置 `FLoading := False`，确保设计期属性修改能触发重绘
- **默认文字**：`ResetSettings` 中设置 `FButtonText := 'Button'`
- **SetButtonStyle 修复**：恢复 `Redraw` 调用，确保样式切换能实时预览

### 动画优化
- Ripple 动画完成后自动停止定时器
- 仅在需要动画时启动定时器

### 字体调整
- 默认字体大小从 14 改为 12

## 统一字体大小规范（2026-06-06）

以 **12px** 为标准基准，统一所有组件的默认字体大小：

### 字体层次

| 层次 | 大小 | 用途 |
|------|------|------|
| 标准正文 | 12px | 按钮文字、标签文字、选项文字、Tab 文字、输入文字 |
| 大号文字 | 14px | Large 尺寸按钮、步骤序号 |
| 小号文字 | 11px | Small 尺寸按钮 |
| 辅助文字 | 10px | Caption、Description、Helper、值标签、进度标签 |

### 各组件字体大小

| 组件 | 属性 | 调整前 | 调整后 |
|------|------|--------|--------|
| TDSkButton | Font.Size | 12 | 12（不变） |
| TDSkButtonGroup | Small | 12 | 11 |
| TDSkButtonGroup | Medium | 14 | 12 |
| TDSkButtonGroup | Large | 16 | 14 |
| TDSkSelect | Font.Size | 13 | 12 |
| TDSkSelect | LabelFont.Size | 12 | 12（不变） |
| TDSkSelect | dropdown fallback | 10 | 12 |
| TDSkEdit | Font.Size | 13 | 12 |
| TDSkEdit | LabelFont.Size | 12 | 12（不变） |
| TDSkTabs | TabFont.Size | 14 | 12 |
| TDSkStepper | StepFont.Size | 14 | 12 |
| TDSkStepper | LabelFont.Size | 13 | 12 |
| TDSkStepper | DescriptionFont.Size | 11 | 10 |
| TDSkPanel | CaptionFont.Size | 未设置 | 12 |
| TDSkRadio | Font.Size | 10 | 10（不变） |
| TDSkCheckbox | Font.Size | 10 | 10（不变） |
| TDSkSwitch | Font.Size | 10 | 10（不变） |
| TDSkRadioGroup | ItemFont.Size | 13 | 12 |
| TDSkRadioGroup | CaptionFont.Size | 10 | 10（不变） |
| TDSkCheckboxGroup | ItemFont.Size | 13 | 12 |
| TDSkCheckboxGroup | CaptionFont.Size | 10 | 10（不变） |
| TDSkSwitchGroup | ItemFont.Size | 13 | 12 |
| TDSkSwitchGroup | CaptionFont.Size | 10 | 10（不变） |
| TDSkProgressBar | Font.Size | 10 | 10（不变） |
| TDSkCircularProgress | Font.Size | 10 | 10（不变） |
| TDSkSlider | Font.Size | 10 | 10（不变） |
| TDSkSnackbar | Font.Size | 12 | 12（不变） |
| TDSkSnackbar | ActionFont.Size | 12 | 12（不变） |
| TDSkSnackbar | design-time fallback | 10 | 12 |

### SkiaVclControls.MUIHelper

```pascal
uses SkiaVclControls.MUIHelper;
ApplyMUITheme(Button, muiPrimary, muiContained);
```

代码级 MUI 主题应用函数，与 Button 的 `MUIColorScheme`/`MUIStyle` 属性使用相同的配色常量。

## 枚举类型

```pascal
TDSkButtonStyle    = (bsRectangle, bsRoundRect, bsCircle);
TDSkButtonType     = (btNormal, btToggle);
TDSkImageAlign     = (iaLeft, iaRight, iaTop, iaBottom, iaCenter);
TDSkCaptionPosition = (cpTopLeft, cpTopCenter, cpTopRight, cpLeftCenter, cpCenter,
                       cpRightCenter, cpBottomLeft, cpBottomCenter, cpBottomRight);
TDSkMUIColorScheme = (muiPrimary, muiSecondary, muiError, muiWarning, muiInfo, muiSuccess, muiSchemeNone);
TDSkMUIStyle       = (muiContained, muiOutlined, muiText, muiStyleNone);
TDSkHoverEffect    = (heNone, heRipple, heGlow, heScaleUp);
TDSkPanelStyle     = (psElevated, psFilled, psOutlined, psSurface, psPrimaryContainer,
                      psSecondaryContainer, psErrorContainer, psStyleNone);
TDSkButtonGroupOrientation = (bgoHorizontal, bgoVertical);
TDSkButtonGroupVariant = (bgvContained, bgvOutlined, bgvText);
TDSkButtonGroupSize = (bgsSmall, bgsMedium, bgsLarge);
TDSkRadioLabelPlacement = (rlpTop, rlpBottom, rlpLeft, rlpRight);
TDSkRadioGroupOrientation = (rgoVertical, rgoHorizontal);
TDSkSliderOrientation = (sloHorizontal, sloVertical);
TDSkSliderValueLabelDisplay = (svldAuto, svldOn, svldOff);
TDSkSliderTrack = (stNormal, stFalse, stInverted);
TDSkSwitchSize = (sssSmall, sssMedium);
TDSkSelectVariant = (svOutlined, svFilled, svUnderline);
TDSkSelectLabelPlacement = (slpFloat, slpShrink);
TDSkSelectSize = (ssMedium, ssSmall);
TDSkEditVariant = (evOutlined, evFilled, evUnderline);
TDSkEditLabelPlacement = (elpFloat, elpShrink);
TDSkEditSize = (esMedium, esSmall);
TDSkProgressBarVariant = (pbvDeterminate, pbvIndeterminate, pbvBuffer);
TDSkProgressBarOrientation = (pboHorizontal, pboVertical);
TDSkCircularProgressVariant = (cpvDeterminate, cpvIndeterminate);
TDSkStepperOrientation = (stoHorizontal, stoVertical);
TDSkStepStatus = (ssPending, ssActive, ssCompleted, ssError);
TDSkStepperVariant = (svLinear, svNonLinear);
TDSkStepperLabelLayout = (sllStandard, sllAlternative);
TDSkTabsVariant = (tvStandard, tvBottomNav);
TDSkTabsAlignment = (taLeft, taCenter, taFullWidth);
TDSkTabsOrientation = (toHorizontal, toVertical);
TDSkTabIndicatorColor = (ticPrimary, ticSecondary);
TDSkTabTextColor = (ttcPrimary, ttcSecondary);
TDSkSnackbarPosition = (spTopLeft, spTopCenter, spTopRight, spBottomLeft, spBottomCenter, spBottomRight);
TDSkSnackbarSeverity = (snkSuccess, snkError, snkWarning, snkInfo, snkNone);
TDSkSnackbarVariant = (snvStandard, snvFilled, snvOutlined);
```

## 编译方式

### IDE 安装

1. 在 Delphi 13.1 IDE 中打开 `SkiaVclControls.dpk`
2. IDE 会提示添加 `Skia.Package.VCL` 和 `Skia.Package.RTL` 依赖，点击 OK
3. 右键 → **Install**
4. Tool Palette 出现 **SkiaVclControls** 分类

### 命令行编译

```pwsh
cd "E:\temp\SkiaControls"
.\build.bat
```

## 依赖

- **Delphi**: 13.1+ (内置 Skia 支持)
- **Skia.Package.VCL**: Delphi 内置 Skia VCL 包
- **Skia.Package.RTL**: Delphi 内置 Skia RTL 包

## 关键技术点

- **基类**: `TSkCustomWinControl` (Vcl.Skia)，已有 `Opacity: Byte` 属性
- **绘制**: `ISkCanvas` 接口，使用 `TSkPathBuilder` 绘制路径
- **圆角**: `TSkRoundRect` + `DrawRoundRect` / `TSkPathBuilder.AddRoundRect`
- **颜色**: `TAlphaColor` (ARGB 格式: `$AARRGGBB`)
- **悬停**: `CM_MOUSEENTER` / `CM_MOUSELEAVE` 消息
- **字体**: `TFont` 对象 + `TSkTypeface.MakeFromName` 创建 Skia 字体；基类提供 `GetDefaultFontName` 函数，自动检测系统是否安装 Microsoft YaHei（依次尝试 `Microsoft YaHei` / `Microsoft YaHei UI` / `微软雅黑`），有则使用，否则回退 Tahoma。结果缓存，只检测一次
- **高 DPI**: `TDSCustomSkControl` 统一读取当前窗口 PPI；Skia 字体使用 `TFont.Size` 点数转换为像素，圆角、边框、间距和 ButtonGroup 默认尺寸按 `CurrentPPI / 96` 缩放
- **中文**: .dfm 文件中使用 Unicode 转义序列 `#xxxxx` 格式；Skia 的 `TSkTypeface.MakeFromName` 不像 GDI 有自动字体链接，需确保字体本身包含中文字形
- **动画**: `TTimer` 16ms 定时器驱动，按下缩放 0.95 倍，悬停放大 1.03 倍
- **悬停效果**: Ripple (涟漪脉冲)、Glow (发光边框+模糊)、ScaleUp (放大)
- **图标渲染**: `TDSkButton` 首次使用时执行 `ImageList.GetBitmap` → `Vcl.Skia.BitmapToSkImage`，随后复用缓存的 `ISkImage`，仅在 `Images` / `ImageIndex` / ImageList 尺寸或内容变化时失效
- **ImageList 监听**: `TChangeLink` 注册到 `TCustomImageList`，尺寸或内容变化时自动触发 `Redraw`；`Notification` 处理 ImageList 删除时清除引用
- **ButtonGroup 布局**: `AlignControls` 根据 `Orientation` / `FullWidth` / `Spacing` 统一排布子按钮，并按首尾位置调整逐角圆角，形成连续按钮组。
- **RadioGroup 自绘**: `TDSkRadioGroup` 自行绘制所有单选按钮，不创建子组件，避免 DFM 设计期命名冲突。
- **Select 下拉弹出**: `TDSkSelectDropDownForm` 使用 `TCustomForm` + `WS_POPUP` 样式实现无边框弹出窗口，`PaintWindow` 使用 GDI `TCanvas` 绘制选项列表，通过 `WM_ACTIVATE` 失活消息自动关闭。
- **Select 浮动标签**: Outlined 变体标签上浮时，`DrawBorder` 在边框路径上留出标签宽度缺口，`DrawLabel` 用白色矩形覆盖边框段。使用 `ISkFont.GetMetrics()` 获取实际字体度量（Ascent/Descent）定位，确保中文和大字号不会被截取。
- **Select Underline 变体**: 透明背景，底部横线上移 6px 靠近文字（`LRect.Bottom - DpiScaleValue(6)`），与 MUI Standard 样式一致。
- **Edit 文本输入**: `TDSkEdit` 使用 `SetTimer` 窗口定时器实现光标闪烁（530ms），通过 `WM_TIMER` 消息驱动；支持鼠标拖选、双击全选、Ctrl+A/C/X/V 剪贴板操作。`DestroyWnd` 覆写确保窗口销毁前停止定时器。
- **设计期重绘**: 所有组件的 `RequestRedraw` 统一使用 `Redraw`（而非 `Invalidate`），确保设计时和运行时都能即时生效。
- **父控件禁用状态传播**: VCL 的 `TControl.GetEnabled` 只返回自身 `FEnabled`，不检查父控件。基类通过两层机制解决：① `CMEnabledChanged` 递归传播 `Enabled` 给子 `TWinControl`；② `IsParentDisabled` 函数在绘制时向上遍历父控件链检查禁用状态，所有绘制方法使用 `(not Enabled) or IsParentDisabled` 判断。
- **子控件透明渲染**: `TSkCustomWinControl` 的 `IsOpaque` 机制——当 `FBackgroundColor.A < 255` 时 `Paint` 自动创建父背景缓冲区（GDI 捕获），Skia 内容 AlphaBlend 上去，透明区域自然显示父控件背景。`TDSCustomSkControl.SetBackgroundColor` 通过 RTTI 同步 `strict private` 的父类字段。
- **嵌套控件角落渲染策略**:
  - 嵌套在 Skia 控件内的子控件：`ShouldClipWindowRegion = False`（禁用 `SetWindowRgn`），由 `Draw()` 首先用不透明父背景色填充整个矩形区域，然后用 `ClipRoundRect` 绘制圆角内容；
  - 直接放在普通 VCL 控件（Form/Panel）上的顶层 Skia 控件：`ShouldClipWindowRegion = True`（保留 `SetWindowRgn`），角落由父控件的稳定背景提供。
  - 父控件状态变化时，不再无条件重绘全部 Skia 子控件，而是区分“依赖父基础背景”和“依赖父悬停视觉背景”的子控件，按需触发 `Redraw`。
- **Snackbar 图标绘制**: `TDSkSnackbar` 使用 Skia 矢量绘制图标，根据 Severity 类型绘制不同图标：Success=圆圈+勾，Error=圆圈+X，Warning=三角形+感叹号，Info=圆圈+i。图标颜色与背景形成对比，支持 Standard/Filled/Outlined 三种变体。
- **Snackbar 多行文本**: 使用 `WrapTextToLines` 方法按空格分词，逐词测量宽度实现自动换行（最多 2 行），超出部分截断并显示 "..."。`UpdateHeight` 方法根据行数自动调整 Snackbar 高度。最大宽度限制为 560px（匹配 MUI 规范）。

## 已知问题

- ~~**Slider 设计期样式变更不实时更新**: 设计期修改 `ColorScheme`、`Orientation` 等属性后，IDE 画布不会立即刷新显示新样式。~~ 已解决，统一使用 `Redraw` 替代 `Invalidate`。
- ~~**Transparent 属性**: `TSkCustomWinControl` 不直接支持透明，需要进一步研究其内部渲染机制。~~ 已解决，见下方"TSkCustomWinControl 透明渲染机制"。
- ~~**中文输入/显示乱码**: Skia 控件输入中文显示乱码，默认字体不支持中文。~~ 已解决，见下方"已解决"中的"中文输入乱码"和"中文显示乱码"。
- **设计期 Group 控件显示纯灰矩形背景（无网格点）**: `TDSkRadioGroup`、`TDSkCheckboxGroup`、`TDSkSwitchGroup` 在设计器中显示为纯 `clBtnFace` 灰色矩形，遮盖了 IDE 的网格点。根因：`TSkCustomWinControl.Paint` 中 `IsOpaque=False` 时通过 `DrawParentImage` 捕获父背景，但 `DrawParentImage` 向父窗体发送 `WM_PRINTCLIENT` 只能捕获窗体本身的 `clBtnFace` 颜色，**无法捕获 IDE 设计器覆盖层绘制的网格点**。这是 Skia VCL 控件设计时的**固有局限**（所有 `BackgroundColor = Null` 的非不透明 Skia 控件均有此现象，仅因 Group 控件面积较大而更明显）。运行时无网格点，透明效果正常。

## Slider 状态（2026-06-04）

- `TDSkSlider` 已实现并编译通过。
- 支持功能：连续/间续滑块、范围滑块、垂直滑块、MUI 配色方案、值标签、自定义标记。
- 属性设置器统一使用 `RequestRedraw` → `Redraw` 触发重绘。
- 设计期样式变更现已实时更新（统一使用 `Redraw` 替代 `Invalidate`）。

## Radio 状态（2026-06-04）

- `TDSkPanel.CornerRadius = 0`:
  - `PanelStyle` 不再覆盖用户显式设置的圆角。
  - `TDSkPanel` 默认圆角改为 `0`。
  - 基类边框在直角时使用 `Miter`，避免视觉上仍像圆角。
- `TDSkRadio`:
  - 默认 `BackgroundColor = Null`、`BorderColor = Null`、`BorderWidth = 0`、`CornerRadius = 0`。
  - `Draw` 直接绘制透明内容（先 `ACanvas.Clear($00FFFFFF)`，再绘制圆点和文字），不调用 `DrawParentBackground`。
  - `DependsOnParentBackground = False`。
  - `DependsOnParentVisualBackground` 动态判断：当父容器 `HasVisualStateChangesOnMouseTrack = True` 时返回 `True`，确保父容器 hover 时 Radio 重绘以更新 GDI 捕获的父背景缓冲区。
  - 属性刷新统一走 `RequestRedraw` → `Redraw`（设计时和运行时都能生效）。
  - 透明渲染依赖基类 `SetBackgroundColor` 中的 RTTI 同步机制（见下方"TSkCustomWinControl 透明渲染机制"）。
- `TDSkRadioGroup`（及 `TDSkCheckboxGroup`、`TDSkSwitchGroup`）:
  - 默认同样去掉自身背景、边框和圆角。
  - `Draw` 改为 `ACanvas.Clear(TAlphaColors.Null)` + 绘制标题和选项，不再调用 `DrawParentBackground`。
  - `DependsOnParentBackground = False`（不再主动绘制父背景）。
  - `DependsOnParentVisualBackground` 动态判断同 Radio。
  - 设计期已知限制：`TSkCustomWinControl.Paint` 的 `IsOpaque=False` 机制会创建父背景缓冲区，`DrawParentImage` 向父窗体发送 `WM_PRINTCLIENT` 只能捕获 `clBtnFace` 纯色，**捕获不到 IDE 设计器的网格点**。因此设计时 Group 区域显示为纯灰色（clBtnFace），网格点被隐藏。运行时 Grid 不存在，透明效果正常。

## TSkCustomWinControl 透明渲染机制（2026-06-04）

### 问题

`TSkCustomWinControl`（Vcl.Skia）的 `FBackgroundColor` 字段是 `strict private` 的，`TDSCustomSkControl` 声明了自己的 `FBackgroundColor` 字段遮蔽了它。子控件设置 `BackgroundColor := TAlphaColors.Null` 只更新子类字段，父类字段仍为白色（alpha=255）。

### TSkCustomWinControl.Paint 渲染流程

```pascal
function TSkCustomWinControl.IsOpaque: Boolean;
begin
  Result := (not FAllowDrawParentInBackground) or
            (TAlphaColorRec(FBackgroundColor).A = 255);
end;

procedure TSkCustomWinControl.Paint;
begin
  if IsOpaque then
    LBackgroundBuffer := nil          // 不透明：直接 AlphaBlend 到 canvas
  else
  begin
    FBackgroundBuffer := TBitmap.Create;
    DrawParentImage(FBackgroundBuffer.Canvas.Handle);  // GDI 捕获父背景
    LBackgroundBuffer := FBackgroundBuffer;
  end;
  FRender.TryRender(LBackgroundBuffer, FOpacity);
end;
```

`DoRender` 中：当 `ABackgroundBuffer <> nil` 时，Skia 内容 AlphaBlend 到父背景缓冲区上，透明区域自然显示父控件背景；当 `ABackgroundBuffer = nil` 时，AlphaBlend 直接到 canvas，透明像素无法正确显示。

### 解决方案

在 `TDSCustomSkControl.SetBackgroundColor` 中通过 `System.Rtti` 同步父类的 `strict private` 字段：

```pascal
procedure SetParentBackgroundColor(AControl: TSkCustomWinControl; AValue: TAlphaColor);
var
  LCtx: TRttiContext;
  LField: TRttiField;
begin
  LField := LCtx.GetType(TSkCustomWinControl.ClassInfo).GetField('FBackgroundColor');
  if LField <> nil then
    LField.SetValue(AControl, AValue);
end;

procedure TDSCustomSkControl.SetBackgroundColor(const Value: TAlphaColor);
begin
  if FBackgroundColor <> Value then
  begin
    FBackgroundColor := Value;
    SetParentBackgroundColor(Self, Value);  // 同步父类字段
    ...
  end;
end;
```

这样当 Radio 设置 `BackgroundColor := TAlphaColors.Null`（alpha=0）时，`TSkCustomWinControl.FBackgroundColor` 也被设为 alpha=0，`IsOpaque` 返回 `False`，`Paint` 自动创建父背景缓冲区并用 GDI 绘制父背景，Skia 内容透明区域自然显示父控件背景。

### 子控件透明绘制要点

- **真透明控件（Radio）**:
  - `Draw` 方法：只清除为透明 + 绘制自身内容，不调用 `DrawParentBackground`
  - `DependsOnParentBackground = False`：不依赖父背景（由 `TSkCustomWinControl.Paint` 自动处理）
  - `DependsOnParentVisualBackground`：动态判断，父容器有 hover 效果时返回 `True`
- **伪透明控件（已废弃）**: RadioGroup/CheckboxGroup/SwitchGroup 原为"伪透明"策略（`DrawParentBackground` 填充父背景纯色），2026-06-07 改为**真透明**策略（`Clear(TAlphaColors.Null)` + 依赖背景缓冲区），与 Radio/Checkbox/Switch 一致：
  - `Draw` 方法：`Clear(TAlphaColors.Null)` + 绘制内容，不调用 `DrawParentBackground`
  - `DependsOnParentBackground = False`：不依赖父背景（由 `TSkCustomWinControl.Paint` 自动处理）
  - `DependsOnParentVisualBackground`：动态判断，父容器有 hover 效果时返回 `True`

## 绘制性能状态（2026-06-04）

- **本轮目标**: 不改公开 API，优先做低风险性能优化，减少无效 `Redraw`、重复字体创建和按钮图标重复转换。
- **基类 `TDSCustomSkControl`**:
  - 新增 `DependsOnParentBackground` / `DependsOnParentVisualBackground` / `HasVisualStateChangesOnMouseTrack` 三层判定。
  - `CM_MOUSEENTER` / `CM_MOUSELEAVE` 不再无条件重绘整棵 Skia 子树，只刷新真正依赖父悬停视觉的子控件。
  - 新增 `BeginRedrawLock` / `EndRedrawLock` / `CanRedrawNow`，供派生类在批量属性赋值时合并成一次最终重绘。
  - 边框绘制在直角和统一圆角场景下直接走 `DrawRect` / `DrawRoundRect`，仅逐角不一致时保留 `TSkPathBuilder`。
- **`TDSkButton`**:
  - 新增按钮文字字体缓存和文本宽度缓存，避免动画帧内重复 `TSkTypeface.MakeFromName` / `TSkFont.Create` / `MeasureText`。
  - 新增 `ISkImage` 图标缓存；只有 `Images`、`ImageIndex`、ImageList 尺寸或内容变化时才重新转换位图。
  - 组按钮模式下，如果显式提供 `FGroupCornerBackgroundColor`，则不再把自身标记为依赖父背景，减少 ButtonGroup 内部无效重绘。
- **`TDSkPanel`**:
  - `ApplyPanelStyleInternal` 改为批量更新：样式套用期间锁住即时重绘，最后只做一次面板自身刷新和一次按需子控件刷新。
  - `BackgroundHover` / `HoverEnabled` 只有在鼠标当前位于面板内、确实影响可见背景时才级联刷新子控件。
  - 标题绘制新增字体缓存和标题宽度缓存。
- **`TDSkRadio` / `TDSkRadioGroup`**:
  - `TDSkRadio` 改为真正透明绘制：`Draw` 不填充父背景，依赖 `TSkCustomWinControl.Paint` 的 `IsOpaque=False` 机制自动捕获父背景。
  - `TDSkRadio` 增加标签字体缓存和文本宽度缓存。
  - `TDSkRadioGroup` 增加标题字体缓存、项目字体缓存，以及按字符串缓存的项目文字宽度。
- **验证结果**:
  - `ButtonDemo.dproj`、`PanelDemo.dproj` 编译通过。
  - `SkiaVclControls.dproj`、`RadioDemo.dproj` 无源码错误，但输出文件被占用，编译器返回 `output_locked`；需要先关闭占用进程再更新目标文件。

## 颜色转换规则

- VCL 的 `TColor` 不能直接当 `TAlphaColor` 用。
- `clBtnText`、`clWindowText` 等系统色可能是负数或系统色值，直接强转在开启范围检查时容易报错。
- 统一做法：凡是传给 Skia `Paint.Color` 或其它 `TAlphaColor` 入口的 VCL 颜色，一律先调用 `VclColorToAlphaColor`。

## Group 控件透明策略统一（2026-06-07）

### 改动

将 `TDSkRadioGroup`、`TDSkCheckboxGroup`、`TDSkSwitchGroup` 从"伪透明"策略改为**真透明**策略，与对应的单一控件 `TDSkRadio`/`TDSkCheckbox`/`TDSkSwitch` 保持一致：

| 文件 | 原实现 | 新实现 |
|------|--------|--------|
| `RadioGroup.pas:373-386` | `Draw`: 调用 `DrawParentBackground(ACanvas, ADest, LUseVisualState)` 填充父背景纯色 | `Draw`: `ACanvas.Clear(TAlphaColors.Null)` 清空为透明 |
| `RadioGroup.pas:588-591` | `DependsOnParentBackground = True` | `DependsOnParentBackground = False` |
| `CheckboxGroup.pas:465-477` | 同上 | 同上 |
| `SwitchGroup.pas:490-501` | 同上 | 同上 |

### 设计期"灰色背景"说明

设计器中 Group 控件区域仍显示为纯 `clBtnFace` 灰色。这不是 `Draw` 引起的，而是 Skia 渲染管线的固有行为：
1. `TSkCustomWinControl.Paint`（final）中的 `IsOpaque=False` 机制创建父背景缓冲区
2. 背景缓冲区通过 `DrawParentImage` 调用 `WM_PRINTCLIENT` 捕获父窗体外观
3. `WM_PRINTCLIENT` **只能捕获 `clBtnFace` 纯色，捕获不到 IDE 设计器的网格点**（网格点是 IDE 覆盖层绘制的）

此问题影响所有 `BackgroundColor = Null` 的 Skia VCL 控件，仅因 Group 控件面积较大更明显。运行时无此问题。

## 透明合成基础设施（2026-06-04）

### 目标

所有 Skia 控件统一支持完整 Alpha 通道透明度，父子和兄弟控件重叠时透明区域能互相透视。

### 已完成

- **`SkiaVclControls.Compositor` 单元**: 新增 class helper，将 `protected` 的 `Draw` 方法暴露为 `RenderToCanvas`，使父容器能将子控件内容渲染到自己的 canvas 上。
- **基类 `TDSCustomSkControl`**:
  - 新增 `FSkipPaint: Boolean`（private）—— 父容器合成时跳过子控件自身的 Paint。
  - 新增 `FParentIsCompositing: Boolean`（protected）—— 子控件正在被父容器合成。
  - 新增 `FIsCompositing: Boolean`（protected）—— 自身正在合成子控件。
  - 新增公共方法 `SetSkipPaint` / `SetParentIsCompositing`，供跨单元访问。
  - `WMPaint` 修改：当 `FSkipPaint = True` 时，调用 `ValidateRect` 跳过绘制。
  - `NeedsParentBackgroundFill` 修改：合成模式下返回 `False`，避免覆盖已合成的 canvas 内容。
- **`TDSkPanel`**: 新增 `WMPaint` 覆写，实现完整的 backing bitmap 合成：
  1. 创建 32-bit ARGB backing bitmap
  2. 用 `TSkSurface.MakeRasterDirect` 创建 Skia surface（注意：必须用 `ScanLine[Height-1]` 作为基地址，因为 TBitmap 是 bottom-up 布局）
  3. 在 surface 上渲染父自身内容
  4. 按 Z-order 从底到顶渲染所有子控件
  5. 释放 surface 引用
  6. `AlphaBlend` 合成结果到屏幕 DC
- **`SkiaVclControls.dpk`**: 新增 `SkiaVclControls.Compositor` 单元。
- **`TDSkButtonGroup`**: 新增 `WMPaint` 覆写，实现与 Panel 相同的 backing bitmap 合成逻辑。
- **兼容性验证**: `TSkSurface.MakeRasterDirect` 与 VCL `TBitmap` 完全兼容，必须使用 `ScanLine[Height-1]` 作为基地址。
- **Demo 验证**: PanelDemo 编译通过并正常运行，无崩溃或访问违例。合成基础设施工作正常。

### 待实现

- **性能优化**: 脏区域追踪、子控件渲染缓存、backing bitmap 缓存（避免每帧重建）。
- **RadioGroup 子控件合成**: 当前 RadioGroup 自绘选项，如需支持嵌套子控件需添加合成逻辑。

### 技术约束

- `TSkCustomWinControl.Paint` 是 `final` 方法，无法覆盖。
- `FRender` 是 `strict private`，无法从外部访问。
- 每个控件是独立 HWND，兄弟控件之间无法通过 GDI 互相"看到"。
- DWM 对 `WS_EX_TRANSPARENT` 的处理可能产生闪烁。

## 已解决

- **Edit 关闭 Form 时定时器崩溃**: `TDSkEdit` 在关闭包含它的 Form 时，`CreateWnd` 中报访问违例。
  - **根因**: 光标定时器使用 `SetTimer(Handle, 1, ...)` 创建窗口定时器，但缺少 `WM_TIMER` 消息处理；Form 销毁时窗口 Handle 被销毁和重建（`DestroyWnd`/`CreateWnd` 循环），定时器仍在运行，`KillTimer(Handle, 1)` 访问已销毁的 Handle 触发 `CreateWnd`。
  - **修复（三处）**:
    1. 添加 `WMTimer` 消息处理，定时器 ID=1 时调用 `CaretTimerTick` 切换光标可见性
    2. 添加 `DestroyWnd` 覆写，窗口销毁前先停止定时器
    3. `StopCaretTimer` / `StartCaretTimer` / `ResetCaretBlink` 在调用 `KillTimer`/`SetTimer` 前检查 `HandleAllocated`
- **子控件圆角白色矩形框**: `TDSkPanel` 内放置 `TDSkButton` 或嵌套 `TDSkPanel` 时，内部控件圆角外出现白色矩形框。
  - **根因**: `TSkCustomWinControl` 渲染前通过 `DrawParentBackground` 向父控件发送 `WM_ERASEBKGND`，将父背景色填入子控件 DIB 位图作为角落底色。原 `TDSkPanel` 的 `WMEraseBkgnd` 只返回 1 不实际填充，子控件位图角落保持 `TBitmap` 默认白色，覆盖在面板渲染内容之上形成白色矩形。标准 `TPanel` 能正常工作正是因为其 `WM_ERASEBKGND` 会实际 GDI 填充面板背景色。
  - **修复**: 在 `TDSkPanel` 中重写 `WMEraseBkgnd`，用 GDI `CreateSolidBrush`/`FillRect` 填充 `GetBackgroundColor` 返回的面板背景色，使子控件圆角外角落显示正确的父面板背景。
- **嵌套 Panel 颜色切换后角落残留旧颜色**: 程序化切换外层 `TDSkPanel` 背景色后，内嵌的圆角子 Panel 四周角落仍显示切换前的颜色。
  - **根因**: `SetWindowRgn` + `WS_CLIPCHILDREN` + `DWM` 三者共同导致：
    1. 父 Panel 的 `WS_CLIPCHILDREN` 使其绘制时跳过子控件的整个 HWND 矩形区域（包括圆角外角落）→ 父控件 DWM backing buffer 在该位置永远停留在初始值；
    2. 子控件的 `SetWindowRgn` 圆角裁剪使 AlphaBlend 目标 DC 受 OS 限制 → 子控件自身也无法向角落位置写入任何像素；
    3. DWM 合成时，子控件角落透明 → 透出父控件 backing buffer → 颜色停留在旧值，任何 `Invalidate` 调用均无法打破此循环。
  - **修复（三处）**:
    1. `TDSCustomSkControl.ShouldClipWindowRegion`：当 `Parent is TDSCustomSkControl` 时返回 `False`，禁用子控件的 `SetWindowRgn`，使 AlphaBlend 可以向角落写入像素；
    2. `TDSCustomSkControl.Draw()` / `TDSkButton.Draw()`：开头用不透明的父背景色（`GetParentBackgroundColor`）填充整个控件矩形，确保角落 A=255，覆盖父控件 DWM buffer 中的过时内容；
    3. `SetBackgroundColor` / `SetBackgroundHover` / `CMMouseEnter` / `CMMouseLeave`：颜色或悬停状态变化时对所有 Skia 子控件调用 `Redraw`（而非 VCL 的 `Invalidate`）触发 Skia 绘图管线。
- **MUI Outlined/Text 样式悬停时文字不可见**: `muiOutlined` 和 `muiText` 样式下，悬停时背景变为深色，但 `FontHover` 也被设为相同的深色。
  - **修复**: Outlined/Text 样式的 `FontHover` 和 `FontChecked` 设为白色 (`$FFFFFFFF`)；Contained 样式保持与 `FontColor` 一致。
- **按钮图标不显示**: `DrawButtonImage` 方法体为空（"暂时留空"），未实现图标绘制。
  - **修复**: 实现完整的图标绘制逻辑：`ImageList.GetBitmap` → `Vcl.Skia.BitmapToSkImage` → `Canvas.DrawImage`。使用 `FillChar` 清空位图为透明以支持 SVG Alpha 通道。`DrawButtonText` 根据 `ImageAlign` 调整文字位置。
- **ImageList 尺寸变化后按钮图标不更新**: 按钮未监听 ImageList 变化通知。
  - **修复**: 使用 `TChangeLink` 注册到 `TCustomImageList`，`OnChange` 回调触发 `Redraw`。`SetImages` 中自动注册/注销，`Destroy` 中清理。`Notification` 处理 ImageList 被删除时清除引用。
- **RadioGroup 设计期命名冲突**: `TDSkRadioGroup` 运行时自动创建子 `TDSkRadio` 组件会产生 DFM 命名冲突。
  - **根因**: `CreateRadioButtons` 方法中使用固定命名规则创建子组件，与设计期已存在的组件名冲突。
  - **修复**: 重写 `TDSkRadioGroup` 为自绘模式，不再创建子 `TDSkRadio` 组件，在 `Draw` / `DrawItem` 中自行绘制所有单选按钮。
- **Radio 父 Panel hover 时背景色异常**: 当 `TDSkPanel` 开启 `HoverEnabled` 时，hover 到面板上 Radio 出现明显的背景色。
  - **根因**: `TSkCustomWinControl.FBackgroundColor` 是 `strict private` 的，`TDSCustomSkControl` 有自己的 `FBackgroundColor` 字段遮蔽了它。Radio 设置 `BackgroundColor := TAlphaColors.Null` 只更新子类字段，父类 `TSkCustomWinControl.FBackgroundColor` 仍为白色（alpha=255），导致 `IsOpaque = True`，不创建父背景缓冲区，透明像素无法正确显示。
  - **修复**: 在 `TDSCustomSkControl.SetBackgroundColor` 中通过 `System.Rtti` 同步 `TSkCustomWinControl.FBackgroundColor`，使 `IsOpaque = False`，`Paint` 自动创建父背景缓冲区。`TDSkRadio.Draw` 改为只清除为透明 + 绘制自身内容，不调用 `DrawParentBackground`。
- **中文输入乱码**: `TDSkEdit` 输入中文字符显示为乱码。
  - **根因**: `WMChar` 消息处理中使用 `Chr(Message.CharCode)` 将 Unicode 码位截断为 `Byte`（`Chr` 只接受 0-255），中文字符码位 > 255 被丢弃高字节。
  - **修复**: 将 `Chr(Message.CharCode)` 改为 `Char(Message.CharCode)`（`Char` 是 `WideChar`，可正确存储中文字符）。
- **中文显示乱码**: 所有组件默认字体为 Tahoma/Segoe UI，Skia 渲染时不显示中文字形。
  - **根因**: Skia 的 `TSkTypeface.MakeFromName` 不像 GDI 有自动字体链接（font linking）机制。GDI 创建 Tahoma 字体后遇到中文字符会自动回退到中文字体，Skia 只显示缺失字形。
  - **修复（两部分）**:
    1. **源码**: 在 `SkiaVclControls.Base.pas` 新增 `GetDefaultFontName` 函数，通过 `Screen.Fonts` 检测系统是否安装 Microsoft YaHei（依次尝试 `Microsoft YaHei` / `Microsoft YaHei UI` / `微软雅黑`），有则使用，否则回退 Tahoma。所有 12 个组件源文件的默认字体名从 `'Tahoma'`/`'Segoe UI'` 改为调用 `GetDefaultFontName`。`TDSkEdit` 和 `TDSkSelect` 中硬编码的 `MakeFromName('Tahoma', ...)` 也同步修改。
    2. **DFM**: 批量更新所有 Demo 的 `.dfm` 文件，将 `Font.Name = 'Tahoma'` 和 `Font.Name = 'Segoe UI'` 替换为 `Font.Name = 'Microsoft YaHei'`（含 `CaptionFont`、`LabelFont`、`ItemFont` 等变体）。
- **Radio/RadioGroup 父 Panel hover 时背景不跟随**: Panel 开启 `HoverEnabled` 后，hover 时 Radio 和 RadioGroup 的背景色不随 Panel hover 背景色变化。
  - **根因**: Radio 和 RadioGroup 的 `DependsOnParentVisualBackground` 返回 `False`，Panel hover 触发 `RedrawDependentSkiaChildren(True)` 时跳过了它们，导致父背景缓冲区（GDI 捕获）和 `DrawParentBackground` 获取的父背景色不更新。此外 RadioGroup 的 `Draw` 中 `DrawParentBackground(ACanvas, ADest, False)` 使用 `GetParentBaseBackgroundColor`（只返回存储背景色，不考虑 hover 状态）。
  - **修复（三处）**:
    1. `TDSCustomSkControl.HasVisualStateChangesOnMouseTrack` 从 `protected` 提升为 `public`，使子控件可查询父容器的视觉状态变化能力。
    2. `TDSkRadio.DependsOnParentVisualBackground` 和 `TDSkRadioGroup.DependsOnParentVisualBackground` 改为动态判断：当父容器 `HasVisualStateChangesOnMouseTrack = True` 时返回 `True`。
    3. `TDSkRadioGroup.Draw` 中 `DrawParentBackground` 的 `AUseVisualState` 参数改为动态判断：当父容器有 hover 效果时传 `True`，使 `DrawParentBackground` 使用 `GetParentBackgroundColor`（含 hover 状态）而非 `GetParentBaseBackgroundColor`。

## Checkbox 状态（2026-06-04）

- `TDSkCheckbox` 已实现并编译通过。
- 支持功能：三态（Unchecked / Checked / Indeterminate）、MUI 配色方案、透明背景、3px 圆角矩形。
- 标准 √ 勾选图标 + 横线不确定图标，使用 `TSkPathBuilder` 绘制。
- 透明策略同 Radio：`BackgroundColor = Null`、`DependsOnParentBackground = False`。

- `TDSkCheckboxGroup` 已实现并编译通过。
- 支持功能：多选/单选模式、垂直/水平布局、MUI 配色方案、悬停高亮。
- `Exclusive = False`（默认多选），`Exclusive = True` 切换单选。
- `CheckedItems: TList<Integer>` 存储选中索引，`IsItemChecked` / `SetItemChecked` / `ClearCheckedItems` 方法。
- (2026-06-07) 透明策略改为真透明：`Draw` 用 `Clear(TAlphaColors.Null)` 替代 `DrawParentBackground`，`DependsOnParentBackground = False`。

- Demo 验证：`CheckboxDemo.dproj` 编译通过。

## Switch 状态（2026-06-05）

- `TDSkSwitch` 已实现并编译通过。
- 支持功能：轨道 + 滑块滑动开关、Small/Medium 两种尺寸、MUI 配色方案、透明背景。
- 视觉规范：轨道圆角矩形（圆角 = 高度/2），白色圆形滑块带阴影。
- 透明策略同 Radio/Checkbox：`BackgroundColor = Null`、`DependsOnParentBackground = False`。

- `TDSkSwitchGroup` 已实现并编译通过。
- 支持功能：多选/单选模式、垂直/水平布局、MUI 配色方案、悬停高亮、Small/Medium 尺寸统一。
- `Exclusive = False`（默认多选），`Exclusive = True` 切换单选。
- `CheckedItems: TList<Integer>` 存储选中索引，`IsItemChecked` / `SetItemChecked` / `ClearCheckedItems` 方法。
- 未选中项显示灰色轨道（`#E0E0E0`），选中项显示主题色轨道。
- (2026-06-07) 透明策略改为真透明：`Draw` 用 `Clear(TAlphaColors.Null)` 替代 `DrawParentBackground`，`DependsOnParentBackground = False`。

- Demo 验证：`SwitchDemo.dproj` 编译通过。
- 包编译：`SkiaVclControls.dproj` 输出文件被占用（已知问题），需关闭占用进程后重新编译。

## Select 状态（2026-06-05）

- `TDSkSelect` 已实现并编译通过。
- 支持功能：Outlined / Filled / Underline 三种变体、浮动标签动画、下拉列表选择、清除按钮、错误状态、MUI 配色方案、Size 尺寸属性。
- 下拉列表使用独立弹出窗口（`TDSkSelectDropDownForm`），GDI 绘制，支持滚动和键盘导航。
- 透明策略同 Radio/Checkbox：`BackgroundColor = Null`、`DependsOnParentBackground = False`。
- 主控件使用 Skia 绘制（边框、标签、箭头图标等），下拉列表使用 GDI 绘制。
- 默认文字颜色：#495057（深灰色）
- 默认输入字号：12pt
- 默认标签字号：12pt
- slpFloat 模式：无选中项时标签居中显示在框内充当占位符，有选中项时标签上浮到框线（标签中心对齐边框线）
- 标签定位使用 `ISkFont.GetMetrics()` 获取实际字体度量，适配中文和大字号
- ssMedium 高度 62px，ssSmall 高度 46px
- 支持三种变体：Outlined（边框）、Filled（灰色底+底部边框）、Underline（透明背景+底部横线）

- Demo 验证：`SelectDemo.dproj` 编译通过。

## Edit 状态（2026-06-05）

- `TDSkEdit` 已实现并编译通过。
- 支持功能：Outlined / Filled / Underline 三种变体、浮动标签动画、文本输入、选区操作、清除按钮、错误状态、MUI 配色方案、Size 尺寸属性、密码模式、最大长度限制。
- 透明策略同 Radio/Checkbox：`BackgroundColor = Null`、`DependsOnParentBackground = False`。
- 文本输入使用 Skia 绘制（边框、标签、文本、光标、选区等），支持光标闪烁（530ms 间隔）和鼠标拖选。
- 默认文字颜色：#495057（深灰色）
- 默认输入字号：12pt
- 默认标签字号：12pt
- elpFloat 模式：无文本时标签居中显示在框内充当占位符，有文本/焦点时标签上浮到框线（标签中心对齐边框线）
- 标签定位使用 `ISkFont.GetMetrics()` 获取实际字体度量，适配中文和大字号
- esMedium 高度 62px，esSmall 高度 46px
- 支持三种变体：Outlined（边框）、Filled（灰色底+底部边框）、Underline（透明背景+底部横线）
- 键盘支持：方向键移动光标、Home/End、Shift+方向键选区、Ctrl+A/C/X/V、Backspace/Delete
- 显示风格与 `TDSkSelect` 一致
- 光标定时器使用 `SetTimer(Handle, 1, ...)` 创建窗口定时器，通过 `WM_TIMER` 消息处理闪烁
- 修复关闭 Form 时定时器崩溃：`StopCaretTimer` / `StartCaretTimer` / `ResetCaretBlink` 在访问 `Handle` 前检查 `HandleAllocated`；新增 `DestroyWnd` 覆写在窗口销毁前停止定时器
- 修复中文输入乱码：`WMChar` 中 `Chr(Message.CharCode)` 改为 `Char(Message.CharCode)`

- 包编译：`SkiaVclControls.dproj` 编译通过。
- Demo 验证：`EditDemo.dproj` 编译通过。

## Progress 状态（2026-06-05）

- `TDSkProgressBar`（线性进度条）已实现并编译通过。
  - 支持功能：Determinate（定量）/ Indeterminate（不定量动画）/ Buffer（缓冲）三种变体。
  - 水平/垂直方向、MUI 配色方案、自定义颜色（BarColor/TrackColor）。
  - 圆角末端（Rounded）、百分比标签（ShowLabel）、字体自定义。
  - 不定量动画：TTimer 16ms 驱动，两根条形循环流动，sin 曲线控制宽度变化。
  - 缓冲模式：半透明缓冲条 + 实心进度条。
  - 透明策略同 Slider：`BackgroundColor = Null`、`DependsOnParentBackground = True`。

- `TDSkCircularProgress`（环形进度条）已实现并编译通过。
  - 支持功能：Determinate（定量）/ Indeterminate（不定量旋转动画）两种变体。
  - MUI 配色方案、自定义颜色（ProgressColor/TrackColor）。
  - 可调圆环直径（CircleSize，默认 40）和线条粗细（Thickness，默认 3.6）。
  - 百分比标签居中显示在圆环内（ShowLabel）。
  - 不定量动画：旋转弧线，弧长从小到大再到小循环变化（sin 曲线）。
  - 弧线端点使用 Round Cap，从顶部（-90度）开始顺时针绘制。

- 新增枚举类型：
  - `TDSkProgressBarVariant = (pbvDeterminate, pbvIndeterminate, pbvBuffer)`
  - `TDSkProgressBarOrientation = (pboHorizontal, pboVertical)`
  - `TDSkCircularProgressVariant = (cpvDeterminate, cpvIndeterminate)`

- Demo 验证：`ProgressBarDemo.dproj` 编译通过。
  - 演示内容：线性进度条（Determinate/Indeterminate/Buffer/Label）、环形进度条（Determinate/Indeterminate/Label）、颜色方案选择器、模拟进度动画。

## Stepper 状态（2026-06-05）

- `TDSkStepper`（步骤条）已实现并编译通过。
  - 支持功能：水平/垂直方向、线性/非线性模式、步骤状态管理、连接线显示。
  - 步骤状态：Pending（灰色空心圆+数字）、Active（主题色实心圆+白色数字）、Completed（主题色实心圆+白色勾）、Error（红色实心圆+白色叉）。
  - 标签布局：Standard（标签在右侧）或 Alternative（标签在图标下方，仅水平有效）。
  - 连接线：已完成步骤之间显示主题色连接线，否则显示灰色连接线。
  - 透明策略同 RadioGroup：`BackgroundColor = Null`、`DependsOnParentBackground = True`。

- 新增属性：
  - `StepSpacing: Single` — 步骤间距（默认 60，最小 40）
  - `AutoFit: Boolean` — 自适应间距（默认 False）
  - 自动计算公式：`间距 = (控件宽度 - 首尾边距 - 步骤图标总宽度 - 80) / (步骤数量 - 1)`
  - 水平布局时，标签文字超出可用宽度会自动截断并添加 `...`
  - 为最后一个步骤预留 80 像素文字显示空间

- 新增枚举类型：
  - `TDSkStepperOrientation = (stoHorizontal, stoVertical)`
  - `TDSkStepStatus = (ssPending, ssActive, ssCompleted, ssError)`
  - `TDSkStepperVariant = (svLinear, svNonLinear)`
  - `TDSkStepperLabelLayout = (sllStandard, sllAlternative)`

- 包编译：`SkiaVclControls.dpk` 编译通过。

## Material-UI 默认配色

| 颜色        | Main    | Light   | Dark    |
| --------- | ------- | ------- | ------- |
| Primary   | #1976D2 | #42A5F5 | #1565C0 |
| Secondary | #9C27B0 | #BA68C8 | #7B1FA2 |
| Error     | #D32F2F | #EF5350 | #C62828 |
| Warning   | #ED6C02 | #FF9800 | #E65100 |
| Info      | #0288D1 | #03A9F4 | #01579B |
| Success   | #2E7D32 | #4CAF50 | #1B5E20 |

## 中文字体支持（2026-06-05）

- **问题**: 所有 Skia 控件默认字体为 Tahoma/Segoe UI，Skia 渲染时不自动回退到中文字体（GDI 有 font linking，Skia 没有），导致中文显示为缺失字形。`TDSkEdit` 的 `WMChar` 使用 `Chr()` 截断 Unicode 码位，中文输入也变乱码。
- **修复**:
  1. `SkiaVclControls.Base.pas` 新增 `GetDefaultFontName` 函数，检测系统是否安装 Microsoft YaHei，结果缓存。
  2. 12 个组件源文件的默认字体名改为调用 `GetDefaultFontName`。
  3. `TDSkEdit.WMChar` 中 `Chr()` 改为 `Char()`。
  4. 所有 Demo 的 `.dfm` 文件中字体名批量替换为 `Microsoft YaHei`。
- **兼容性**: `GetDefaultFontName` 依次尝试 `Microsoft YaHei` → `Microsoft YaHei UI` → `微软雅黑`，都不存在则回退 Tahoma。非中文 Windows 自动使用 Tahoma。

## Enabled 禁用状态支持（2026-06-06）

### 概述

所有组件现已支持 `Enabled = False` 禁用状态的视觉显示和交互拦截。支持父控件禁用时子控件自动显示灰色（嵌套任意层级）。

### 核心机制

**问题根因**：VCL 的 `TControl.GetEnabled` 只返回自身的 `FEnabled` 字段，不检查父控件状态。当父 Panel 被禁用时，子控件的 `FEnabled` 仍为 `True`，`if not Enabled then` 判断为 `False`，禁用颜色不生效。

**解决方案（两层防护）**：

1. **`CMEnabledChanged` 消息传播**：基类 `TDSCustomSkControl.CMEnabledChanged` 遍历所有子 `TWinControl`，设置 `Enabled` 属性，触发子控件自身的 `CM_ENABLEDCHANGED` 消息链。`TDSkPanel` 和 `TDSkButtonGroup` 的覆写简化为只调用 `inherited`。

2. **`IsParentDisabled` 运行时检查**：在基类新增 `IsParentDisabled` 函数，向上遍历父控件链检查是否有禁用的父控件。所有控件的绘制方法中，将 `if not Enabled then` 改为 `if (not Enabled) or IsParentDisabled then`，确保即使消息传播链未到达，绘制时也能正确显示禁用状态。

```pascal
// 基类新增：运行时检查父控件链禁用状态
function TDSCustomSkControl.IsParentDisabled: Boolean;
var
  LParent: TControl;
begin
  Result := False;
  LParent := Parent;
  while LParent <> nil do
  begin
    if not LParent.Enabled then
      Exit(True);
    LParent := LParent.Parent;
  end;
end;

// 基类 CMEnabledChanged：传播 + 重绘
procedure TDSCustomSkControl.CMEnabledChanged(var Message: TMessage);
var
  i: Integer;
begin
  inherited;
  for i := 0 to ControlCount - 1 do
    if Controls[i] is TWinControl then
      TWinControl(Controls[i]).Enabled := Enabled;
  Redraw;
end;

// 绘制方法中使用：
if (not Enabled) or IsParentDisabled then
  LPaint.Color := $FFBDBDBD;  // 禁用灰色
```

### 完整处理的组件

| 组件 | 背景色 | 字体/内容颜色 | 交互拦截 | IsParentDisabled |
|------|--------|--------------|----------|-----------------|
| TDSkButton | `$FFBDBDBD` | `$FF757575` | ✓ | ✓ |
| TDSkCheckbox | - | `$FFBDBDBD` | ✓ | ✓ |
| TDSkCheckboxGroup | - | `$FFBDBDBD` | ✓ | ✓ |
| TDSkRadio | - | `$FFBDBDBD` | ✓ | ✓ |
| TDSkRadioGroup | - | `$FFBDBDBD` | ✓ | ✓ |
| TDSkSwitch | `$FFBDBDBD` | `$FF757575` | ✓ | ✓ |
| TDSkSwitchGroup | `$FFBDBDBD` | `$FF757575` | ✓ | ✓ |
| TDSkSelect | - | `$FF757575` | ✓ | - |
| TDSkEdit | - | `$FF757575` | ✓ | - |
| TDSkSlider | `$FFBDBDBD` | - | ✓ | - |
| TDSkPanel | `$FFE0E0E0` | - | - | - |
| TDSkButtonGroup | - | - | ✓ | - |
| TDSkCircularProgress | `$FFBDBDBD` | - | - | - |
| TDSkProgressBar | `$FFBDBDBD` | - | - | - |
| TDSkStepper | `$FFBDBDBD` | - | - | - |
| TDSkTabs | `$FFBDBDBD` | - | ✓ | - |

### 容器组件 Enabled 状态传递

- **TDSCustomSkControl（基类）**: `CMEnabledChanged` 遍历所有子 `TWinControl`，将 Enabled 状态传递给它们，然后调用 `Redraw`
- **TDSkPanel**: 覆写简化为 `inherited`（基类已处理传播）
- **TDSkButtonGroup**: 覆写简化为 `inherited`（基类已处理传播）

### 禁用状态颜色规范

| 场景 | 颜色值 | 说明 |
|------|--------|------|
| 主题色内容 | `$FFBDBDBD` | 灰色（用于进度条、滑块、步骤等） |
| 轨道/背景 | `$FFE0E0E0` | 浅灰（用于轨道背景） |
| 容器背景 | `$FFE0E0E0` | 浅灰（用于 Panel 背景） |
| 文字 | `$FF757575` | 深灰（用于标签文字） |
| 动画/缓冲 | `$FFF5F5F5` | 更浅灰（用于不定量动画背景） |

## Slider 浮动值标签状态（2026-06-07）

### 目标
拖动 Slider 时在滑块上方显示独立的浮动值标签，不被父控件裁剪。

### 已解决

| 方案 | 结果 | 问题 |
|------|------|------|
| **A. 子控件 TDSkLabel** | 被父控件裁剪 | 子控件绘制受限于父控件窗口区域 |
| **B. 独立 TCustomForm + TLabel** | 背景不透明 | `WS_EX_LAYERED` + `LWA_COLORKEY` 无法正确透明 |
| **C. 独立 TCustomForm + GDI 绘制** | 背景不透明 | 同上 |
| **D. 白色透明色键** | 背景仍不透明 | 可能是 `PaintWindow` 绘制时机问题 |
| **E. 独立透明悬浮窗 + UpdateLayeredWindow** | 已解决 | 使用像素级 Alpha，绕开透明色键不稳定问题 |

### 当前实现
- `TDSkSliderValueLabelForm` 继承 `TCustomForm`，作为独立顶层透明悬浮窗显示。
- 窗体使用 `WS_EX_LAYERED` / `WS_EX_NOACTIVATE` / `WS_EX_TOOLWINDOW` / `WS_EX_TRANSPARENT` / `WS_EX_NOINHERITLAYOUT`，不抢焦点、不接收鼠标、不被父控件裁剪。
- 使用 `UpdateLayeredWindow` + 32 位 DIB Section 提交像素级 Alpha 内容，不再依赖 `LWA_COLORKEY`。
- 文本绘制流程：先在临时 `TBitmap` 黑底上用 GDI 绘制白色文字作为 Alpha mask，再写入预乘 Alpha 的 DIB，最后通过 `UpdateLayeredWindow` 显示。
- 显示时机：仅在 `MouseDown` / 拖动中的 `MouseMove` 显示和更新；`MouseUp` 后通过 `ShowWindow(..., SW_HIDE)` 立即隐藏。
- 注意：曾尝试用 `WM_CAPTURECHANGED` 兜底隐藏浮层，但会被浮层显示过程触发，提前打断 Slider 的鼠标捕获，导致拖动失效，已移除。

## 新增组件（2026-06-07）

### TDSkLabel
- 文件：`SkiaVclControls.LabelControl.pas`（原 `SkiaVclControls.Label.pas`，因 `LABEL` 是保留字而改名）
- Skia 绘制的透明标签组件
- 支持 `AutoSize`、`ColorScheme`、`FontColor` 属性
- 支持文字特效：纯色/线性渐变填充、文字描边、空心字、阴影/发光、水平/垂直对齐
- 新增枚举：`TDSkLabelTextEffect`、`TDSkLabelGradientDirection`、`TDSkLabelTextAlign`、`TDSkLabelVerticalAlign`
- 渐变属性：`TextEffect`、`GradientStartColor`、`GradientEndColor`、`GradientDirection`
- 描边/填充属性：`FillEnabled`、`StrokeEnabled`、`StrokeColor`、`StrokeWidth`
- 阴影属性：`ShadowEnabled`、`ShadowColor`、`ShadowBlur`、`ShadowOffsetX`、`ShadowOffsetY`
- `AutoSize` 会自动为描边和阴影预留边距，避免特效文字被裁剪
- 已新增 `Demo.Frame.LabelControl` 并接入 `AdminDemo` 侧边导航
- 已注册到组件面板

## 当前交接快照（2026-06-07）

已压缩到文档顶部的“当前压缩上下文”章节。后续维护时优先更新顶部短摘要，详细历史仍保留在各组件状态章节中。
