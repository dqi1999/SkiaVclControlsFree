# 透明合成上下文

## 目标

所有 Skia 控件（Panel、Button、Radio、RadioGroup、ButtonGroup）统一支持完整 Alpha 通道透明度，父子和兄弟控件重叠时透明区域能互相透视。

## 技术约束

- `TSkCustomWinControl.Paint` 是 `final` 方法，无法覆盖
- `FRender` 是 `strict private`，无法从外部访问
- 每个控件是独立 HWND，兄弟控件之间无法通过 GDI 互相"看到"
- DWM 对 `WS_EX_TRANSPARENT` 的处理可能产生闪烁

## 已验证的关键发现

### TSkSurface.MakeRasterDirect + VCL TBitmap 兼容性

**完全兼容**，但必须使用 `ScanLine[Height-1]` 作为基地址：

```pascal
// ✅ 正确：ScanLine[Height-1] = 内存最低地址（bottom-up 布局）
LSurface := TSkSurface.MakeRasterDirect(
  TSkImageInfo.Create(Width, Height, TSkColorType.BGRA8888, TSkAlphaType.Premul),
  LBitmap.ScanLine[Height - 1],
  LBitmap.Width * 4);

// ❌ 错误：ScanLine[0] 指向内存最高地址，Skia 写越界 → 访问违例
LSurface := TSkSurface.MakeRasterDirect(
  TSkImageInfo.Create(Width, Height, TSkColorType.BGRA8888, TSkAlphaType.Premul),
  LBitmap.ScanLine[0],  // 访问违例！
  LBitmap.Width * 4);
```

验证程序：`Test\SurfaceTest.dpr`

## 已完成的基础设施

### 新增文件

- `Sources\SkiaVclControls.Compositor.pas` — class helper 暴露 `RenderToCanvas` + `GetSkiaChildControls`

### 基类修改 (`Sources\SkiaVclControls.Base.pas`)

新增字段：
- `FSkipPaint: Boolean`（private）— 父容器合成时跳过子控件 Paint
- `FParentIsCompositing: Boolean`（protected）— 子控件正在被父容器合成
- `FIsCompositing: Boolean`（protected）— 自身正在合成子控件

新增公共方法：
- `SetSkipPaint(AValue: Boolean)` — 跨单元设置 FSkipPaint
- `SetParentIsCompositing(AValue: Boolean)` — 跨单元设置 FParentIsCompositing

修改的方法：
- `WMPaint` — 当 `FSkipPaint = True` 时调用 `ValidateRect` 跳过绘制
- `NeedsParentBackgroundFill` — 合成模式下返回 `False`

### dpk 修改

`SkiaVclControls.dpk` 新增 `SkiaVclControls.Compositor` 单元。

## Backing Bitmap 合成方案（已验证可行但暂时回退）

### 方案概述

父容器维护 backing bitmap，通过 class helper 调用子控件 `Draw` 方法按 Z-order 合成到 backing bitmap，最终 AlphaBlend 到屏幕。

### 尝试过但回退的原因

1. **WMPaint + Draw 双重合成**：`WMPaint` 合成子控件，`Draw` 也被父容器调用导致重复合成
2. **ACanvas.Clear 破坏父内容**：Radio 的 `ACanvas.Clear` 清除整个画布，破坏父容器已合成内容
3. **DrawParentBackground 覆盖父内容**：RadioGroup/ButtonGroup 的 `DrawParentBackground` 填充整个区域
4. **递归合成复杂度**：嵌套容器需要递归合成，增加调试难度

### 未来实现方向

如果要实现兄弟透明，需要：
1. `Draw` 方法中递归合成子控件（不是 WMPaint）
2. 所有控件的 `Draw` 在合成模式下跳过 `ACanvas.Clear` 和 `DrawParentBackground`
3. 父容器的 `WMPaint` 创建 backing bitmap，调用 `Self.RenderToCanvas`，由 `Draw` 递归处理所有子控件
4. 最后 AlphaBlend 到屏幕

## 当前各控件透明处理

| 控件 | 透明机制 | Draw 行为 |
|------|----------|-----------|
| **Panel** | 基类默认（不铺父背景当无圆角） | 继承基类 + 画标题 |
| **Button** | 角落背景填充 + 自身绘制 | 继承基类 |
| **Radio** | `ACanvas.Clear` 真透明 | 清除为透明 + 画圆圈 + 画标签 |
| **RadioGroup** | `DrawParentBackground` 伪透明 | 铺父背景 + 画标题 + 画选项 |
| **ButtonGroup** | `DrawParentBackground` 伪透明 | 铺父背景 + 画设计期手柄 |

## 编译状态

- ✅ 包编译通过（无源码错误）
- ✅ PanelDemo 编译运行正常
- ✅ RadioDemo 编译运行正常
- ⚠️ 输出文件可能被 IDE 锁定（需关闭 IDE 后编译）
